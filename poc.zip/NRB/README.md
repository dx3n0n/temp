To start server, 
RUN this  =  python3 server.py

