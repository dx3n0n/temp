from flask import Flask, jsonify, request, send_from_directory
from fim import fim_bp #fim
from vulnerability_discovery import vuln_bp #vulnerability-discovery
from search_analytics import search_analytics_bp #search-analytics
from threat_intel import threat_intel_bp, init_threat_intel_client #threat-intel
from flask_cors import CORS
import requests
import json
import pandas as pd
from datetime import datetime, timedelta
import urllib3
import logging
from typing import Dict, List, Any, Optional
import os
from dataclasses import dataclass
from config import Config
import asyncio
import threading
import time
import random
import sys
from dotenv import load_dotenv
load_dotenv()  # Load environment variables from .env file



# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Configure detailed logging to dashboard.log
def setup_logging():
    """Setup centralized logging configuration for all modules"""
    
    # Clear any existing handlers
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s'
    )
    
    # Create file handler ONLY (no console handler)
    file_handler = logging.FileHandler('dashboard.log')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)

    # Create console handler only for WARNING and above (no debug/info)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)  # Only show warnings and errors
    console_handler.setFormatter(formatter)
    
    # Configure root logger with ONLY file handler
    logging.basicConfig(
        level=logging.DEBUG,
        handlers=[file_handler]  # Removed console_handler
    )

# Setup logging before creating the app
setup_logging()


log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)

# Registering blueprints
app.register_blueprint(fim_bp)
app.register_blueprint(vuln_bp)
app.register_blueprint(search_analytics_bp)
app.register_blueprint(threat_intel_bp)

@dataclass
class DashboardConfig:
    """Configuration for SOC Dashboard"""
    REFRESH_INTERVAL: int = 30  # seconds
    MAX_ALERTS: int = 5000
    TIMEZONE: str = 'UTC'
    ENABLE_REALTIME: bool = True


class ProfessionalWazuhClient:
    """Enhanced Wazuh client with professional error handling and caching"""
    
    def __init__(self, host: str, username: str, password: str, verify_ssl: bool = False):
        self.base_url = f"https://{host}:9200"
        self.auth = (username, password)
        self.verify_ssl = verify_ssl
        self.session = requests.Session()
        self.session.auth = self.auth
        self.session.verify = self.verify_ssl
        self.logger = logging.getLogger(__name__)
        self._cache = {}
        self._cache_timeout = 300  # 5 minutes
        
    def _make_request(self, endpoint: str, query: Dict = None) -> Dict[str, Any]:
        """Make authenticated request with error handling"""
        try:
            url = f"{self.base_url}/{endpoint}"
            self.logger.debug(f"🔍 Making request to: {url}")
            if query:
                self.logger.debug(f"🔍 Query: {json.dumps(query, indent=2)}")
            
            response = self.session.get(url, json=query, verify=self.verify_ssl, timeout=30)
            self.logger.debug(f"🔍 Response status: {response.status_code}")
            
            response.raise_for_status()
            result = response.json()
            
            self.logger.debug(f"🔍 Response keys: {list(result.keys())}")
            if 'hits' in result:
                total_hits = result['hits']['total']['value']
                actual_hits = len(result['hits']['hits'])
                self.logger.debug(f"🔍 Total hits: {total_hits}, Actual hits: {actual_hits}")
                
                if actual_hits > 0:
                    first_hit = result['hits']['hits'][0]
                    source = first_hit.get('_source', {})
                    self.logger.debug(f"🔍 First hit ID: {first_hit.get('_id')}")
                    self.logger.debug(f"🔍 First hit timestamp: {source.get('@timestamp')}")
                    self.logger.debug(f"🔍 First hit rule groups: {source.get('rule', {}).get('groups', [])}")
            
            return result
        except requests.exceptions.RequestException as e:
            self.logger.error(f"❌ Request failed for {endpoint}: {e}")
            if hasattr(e, 'response') and e.response is not None:
                self.logger.error(f"❌ Response content: {e.response.text}")
            return {"error": str(e), "hits": {"hits": [], "total": {"value": 0}}}
    
    def get_alerts_by_time_range(self, start_time: str, end_time: str, size: int = 1000) -> Dict[str, Any]:
        """Get alerts with advanced time range filtering"""
        cache_key = f"alerts_{start_time}_{end_time}_{size}"
        if cache_key in self._cache and time.time() - self._cache[cache_key]['timestamp'] < self._cache_timeout:
            return self._cache[cache_key]['data']
            
        # Use simpler time query without strict format
        query = {
            "query": {
                "range": {
                    "@timestamp": {
                        "gte": start_time,
                        "lte": end_time
                    }
                }
            },
            "size": size,
            "sort": [{"@timestamp": {"order": "desc"}}],
            "aggs": {
                "severity_stats": {"stats": {"field": "rule.level"}},
                "top_agents": {"terms": {"field": "agent.name.keyword", "size": 10}},
                "alerts_over_time": {"date_histogram": {"field": "@timestamp", "calendar_interval": "hour"}}
            }
        }
        
        self.logger.info(f"📊 Getting alerts from {start_time} to {end_time}")
        result = self._make_request("wazuh-alerts-4.x-*/_search", query)
        self._cache[cache_key] = {'data': result, 'timestamp': time.time()}
        return result
    
    def get_alerts_last_x_hours(self, hours: int = 24, size: int = 1000) -> Dict[str, Any]:
        """Get alerts from last X hours (more reliable method) - Consolidated version"""
        cache_key = f"alerts_last_{hours}_hours_{size}"
        if cache_key in self._cache and time.time() - self._cache[cache_key]['timestamp'] < self._cache_timeout:
            cached_result = self._cache[cache_key]['data']
            self.logger.info(f"📊 Using cached data for last {hours} hours (Age: {time.time() - self._cache[cache_key]['timestamp']:.1f}s)")
            return cached_result

        
        # Use consistent time format and index pattern
        query = {
            "query": {
                "range": {
                    "@timestamp": {
                        "gte": f"now-{hours}h",
                        "lte": "now",
                        "format": "strict_date_optional_time"
                    }
                }
            },
            "size": size,
            "sort": [{"@timestamp": {"order": "desc"}}],
            "_source": {
                "includes": ["*"],
                "excludes": []
            }
        }
        
        self.logger.info(f"📊 Getting alerts from last {hours} hours with size={size}")
        
        # Always use wildcard index pattern for consistency
        result = self._make_request("wazuh-alerts-4.x-*/_search", query)
        
        # Log detailed results
        if result and 'hits' in result:
            total_hits = result['hits']['total']['value']
            actual_hits = len(result['hits']['hits'])
            self.logger.info(f"📊 Query Results - Total: {total_hits}, Returned: {actual_hits}")
            
            if actual_hits > 0:
                first_hit = result['hits']['hits'][0]
                source = first_hit.get('_source', {})
                self.logger.debug(f"📊 First alert timestamp: {source.get('@timestamp')}")
                self.logger.debug(f"📊 First alert description: {source.get('rule', {}).get('description', 'N/A')}")
                self.logger.debug(f"📊 First alert severity: {source.get('rule', {}).get('level', 'N/A')}")
            else:
                self.logger.warning(f"📊 No alerts returned for last {hours} hours")
        
        self._cache[cache_key] = {'data': result, 'timestamp': time.time()}
        return result
    
    
    def get_alerts_last_x_hours_optimized(self, hours: int = 24, size: int = 1000) -> Dict[str, Any]:
        
        return self.get_alerts_last_x_hours(hours=hours, size=size)


    def clear_time_range_cache(self, exclude_key=None):
        """Clear all time-related cache entries except specified one"""
        keys_to_clear = []
        for key in list(self._cache.keys()):
            if ('alerts_last' in key or 'alerts_' in key) and key != exclude_key:
                keys_to_clear.append(key)
        
        for key in keys_to_clear:
            del self._cache[key]
        
        self.logger.info(f"🧹 Cleared {len(keys_to_clear)} time-range cache entries")
        return keys_to_clear

    def get_severity_summary(self) -> Dict[str, Any]:
        """Get severity level summary for dashboard metrics"""
        query = {
            "query": {
                "range": {
                    "@timestamp": {
                        "gte": "now-24h",
                        "lte": "now",
                        "format": "strict_date_optional_time"
                    }
                }
            },
            "size": 0,
            "aggs": {
                "severity_breakdown": {
                    "terms": {"field": "rule.level", "size": 15}
                },
                "total_alerts": {"value_count": {"field": "rule.level"}}
            }
        }
        self.logger.info("📊 Getting severity summary (last 24h)")
        return self._make_request("wazuh-alerts-4.x-*/_search", query)
    
    def get_mitre_coverage(self) -> Dict[str, Any]:
        """Get MITRE ATT&CK technique coverage"""
        query = {
            "query": {
                "range": {
                    "@timestamp": {
                        "gte": "now-24h",
                        "lte": "now",
                        "format": "strict_date_optional_time"
                    }
                }
            },
            "size": 0,
            "aggs": {
                "mitre_tactics": {
                    "terms": {"field": "rule.mitre.tactic.keyword", "size": 20}
                },
                "mitre_techniques": {
                    "terms": {"field": "rule.mitre.technique.keyword", "size": 50}
                }
            }
        }
        self.logger.info("📊 Getting MITRE coverage (last 24h)")
        return self._make_request("wazuh-alerts-4.x-*/_search", query)
    
    def get_fim_events(self, start_time: str = None, end_time: str = None) -> Dict[str, Any]:
        """Get File Integrity Monitoring events"""
        if not start_time:
            start_time = "now-24h"
        if not end_time:
            end_time = "now"
            
        query = {
            "query": {
                "bool": {
                    "must": [
                        {
                            "range": {
                                "@timestamp": {
                                    "gte": start_time,
                                    "lte": end_time,
                                    "format": "strict_date_optional_time"
                                }
                            }
                        },
                        {
                            "term": {
                                "rule.groups": "syscheck"
                            }
                        }
                    ]
                }
            },
            "size": 1000,
            "sort": [{"@timestamp": {"order": "desc"}}]
        }
        
        self.logger.info(f"🔍 Getting FIM events from {start_time} to {end_time}")
        result = self._make_request("wazuh-alerts-4.x-*/_search", query)
        
        # Log FIM-specific debug info
        if result and 'hits' in result:
            total_hits = result['hits']['total']['value']
            actual_hits = len(result['hits']['hits'])
            self.logger.info(f"🔍 FIM Query Results - Total: {total_hits}, Returned: {actual_hits}")
            
            if actual_hits > 0:
                first_hit = result['hits']['hits'][0]
                source = first_hit.get('_source', {})
                self.logger.debug(f"🔍 First FIM hit - ID: {first_hit.get('_id')}")
                self.logger.debug(f"🔍 First FIM hit timestamp: {source.get('@timestamp')}")
                self.logger.debug(f"🔍 First FIM hit rule groups: {source.get('rule', {}).get('groups', [])}")
                self.logger.debug(f"🔍 First FIM hit has syscheck: {'syscheck' in source}")
                if 'syscheck' in source:
                    self.logger.debug(f"🔍 Syscheck keys: {list(source['syscheck'].keys())}")
            else:
                self.logger.warning("🔍 No FIM hits returned, but total hits > 0")
        
        return result


class SOCDataProcessor:
    """Professional data processing for SOC dashboard"""
    
    @staticmethod
    def process_alerts_for_dashboard(raw_alerts: Dict[str, Any], query_info: Dict = None) -> Dict[str, Any]:
        """Process raw alerts into professional SOC formate""" 
        logging.debug("🔄 Processing alerts for dashboard")
        
        if not raw_alerts or 'hits' not in raw_alerts:
            logging.warning("❌ No raw alerts data or hits missing")
            return {
                'summary': SOCDataProcessor.get_empty_summary(),
                'charts': SOCDataProcessor.get_empty_charts(),
                'alerts': [],
                'timeline': [],
                'threat_indicators': [],
                'query_info': query_info or {}
            }
        
        total_hits = raw_alerts['hits']['total']['value']
        actual_hits = len(raw_alerts['hits']['hits'])
        logging.info(f"🔄 Processing {total_hits} total alerts, {actual_hits} returned")
        
        alerts_data = []
        severity_counts = {i: 0 for i in range(1, 16)}
        agent_alerts = {}
        rule_categories = {}
        mitre_tactics = {}
        timeline_data = {}
        threat_indicators = []
        
        for hit in raw_alerts['hits']['hits']:
            alert = SOCDataProcessor.process_single_alert(hit)
            alerts_data.append(alert)
            
            # Update metrics
            severity = alert['severity']
            if severity in severity_counts:
                severity_counts[severity] += 1
            
            agent_name = alert['agent_name']
            agent_alerts[agent_name] = agent_alerts.get(agent_name, 0) + 1
            
            # MITRE ATT&CK processing
            for tactic in alert['mitre_tactics']:
                mitre_tactics[tactic] = mitre_tactics.get(tactic, 0) + 1
            
            # Timeline data
            hour_key = alert['timestamp'][:13]  # Group by hour
            timeline_data[hour_key] = timeline_data.get(hour_key, 0) + 1
            
            # Threat indicators for high severity alerts
            if severity >= 10:
                threat_indicators.append({
                    'timestamp': alert['timestamp'],
                    'severity': severity,
                    'description': alert['rule_description'],
                    'agent': agent_name,
                    'mitre_tactics': alert['mitre_tactics']
                })
        
        result = {
            'summary': SOCDataProcessor.calculate_summary_metrics(
                raw_alerts, severity_counts, len(agent_alerts), threat_indicators
            ),
            'charts': {
                'severity_distribution': severity_counts,
                'top_agents': dict(sorted(agent_alerts.items(), key=lambda x: x[1], reverse=True)[:10]),
                'mitre_tactics': dict(sorted(mitre_tactics.items(), key=lambda x: x[1], reverse=True)[:15]),
                'timeline': timeline_data,
                'rule_categories': rule_categories
            },
            'alerts': alerts_data,
            'threat_indicators': sorted(threat_indicators, key=lambda x: x['severity'], reverse=True)[:20],
            'last_updated': datetime.now().isoformat(),
            'query_info': query_info or {},
            'result_metadata': {
                'total_hits': total_hits,
                'actual_hits': actual_hits,
                'processing_time': datetime.now().isoformat()
            }
        }
        
        logging.info(f"✅ Processed {len(alerts_data)} alerts for dashboard")
        return result
    
    @staticmethod

    def process_alerts_for_dashboard_fast(raw_alerts: Dict[str, Any], query_info: Dict = None) -> Dict[str, Any]:
        """Fast processing version"""
        # For now, use the same processing
        return SOCDataProcessor.process_alerts_for_dashboard(raw_alerts, query_info)

    def process_single_alert(hit: Dict) -> Dict[str, Any]:
        """Process a single alert with comprehensive field extraction"""
        source = hit.get('_source', {})
        rule = source.get('rule', {})
        agent = source.get('agent', {})
        manager = source.get('manager', {})
        data = source.get('data', {})
        
        # Extract MITRE ATT&CK information
        mitre = rule.get('mitre', {})
        
        return {
            'id': hit.get('_id', ''),
            'timestamp': source.get('@timestamp', ''),
            'severity': rule.get('level', 0),
            'rule_id': rule.get('id', ''),
            'rule_description': rule.get('description', ''),
            'agent_name': agent.get('name', 'Unknown'),
            'agent_ip': agent.get('ip', ''),
            'agent_id': agent.get('id', ''),
            'manager': manager.get('name', ''),
            'location': source.get('location', ''),
            'groups': rule.get('groups', []),
            'fired_times': rule.get('firedtimes', 1),
            'mitre_tactics': mitre.get('tactic', []),
            'mitre_techniques': mitre.get('technique', []),
            'mitre_ids': mitre.get('id', []),
            'full_log': source.get('full_log', ''),
            'compliance_frameworks': {
                'pci_dss': rule.get('pci_dss', []),
                'hipaa': rule.get('hipaa', []),
                'nist_800_53': rule.get('nist_800_53', []),
                'gdpr': rule.get('gdpr', []),
                'gpg13': rule.get('gpg13', [])
            },
            'raw_data': source  # Keep original data for advanced analysis
        }
    
    @staticmethod
    def calculate_summary_metrics(raw_alerts, severity_counts, unique_agents, threat_indicators):
        """Calculate professional SOC metrics"""
        total_alerts = raw_alerts['hits']['total']['value']
        high_severity = sum(count for sev, count in severity_counts.items() if 8 <= sev <= 11)
        critical_alerts = sum(count for sev, count in severity_counts.items() if sev >= 12)
        
        return {
            'total_alerts': total_alerts,
            'high_severity_alerts': high_severity,
            'critical_alerts': critical_alerts,
            'unique_agents': unique_agents,
            'active_threats': len(threat_indicators),
            'mitre_techniques_count': len(set(
                tech for indicator in threat_indicators 
                for tech in indicator.get('mitre_tactics', [])
            )),
            'time_range': f"Last Update: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            'data_freshness': datetime.now().isoformat()
        }
    
    @staticmethod
    def get_empty_summary():
        return {
            'total_alerts': 0,
            'high_severity_alerts': 0,
            'critical_alerts': 0,
            'unique_agents': 0,
            'active_threats': 0,
            'mitre_techniques_count': 0,
            'time_range': 'No data available',
            'data_freshness': datetime.now().isoformat()
        }
    
    @staticmethod
    def get_empty_charts():
        return {
            'severity_distribution': {},
            'top_agents': {},
            'mitre_tactics': {},
            'timeline': {},
            'rule_categories': {}
        }


# Initialize components
config = DashboardConfig()
wazuh_client = ProfessionalWazuhClient(
    host=Config.WAZUH_HOST,
    username=Config.WAZUH_USERNAME,
    password=Config.WAZUH_PASSWORD,
    verify_ssl=Config.WAZUH_VERIFY_SSL
)
data_processor = SOCDataProcessor()

# Initialize threat intelligence client
init_threat_intel_client(wazuh_client=wazuh_client)

# Real-time data management
class RealTimeDataManager:
    """Manage real-time data updates and caching"""
    
    def __init__(self):
        self.current_data = None
        self.last_update = None
        self.is_updating = False
        self.subscribers = []
        self.logger = logging.getLogger(__name__)
    
    def update_data(self):
        """Update data in background"""
        if self.is_updating:
            return
        
        self.is_updating = True
        try:
            self.logger.info("🔄 Starting background data update")
            # Use the consistent method with explicit parameters
            raw_alerts = wazuh_client.get_alerts_last_x_hours(hours=24, size=1000)
            query_info = {
                'method': 'background_update',
                'hours': 24,
                'size': 1000,
                'update_time': datetime.now().isoformat()
            }
            processed_data = data_processor.process_alerts_for_dashboard(raw_alerts, query_info)
            self.current_data = processed_data
            self.last_update = datetime.now()
            self.logger.info(f"✅ Background update complete. Alerts: {len(processed_data.get('alerts', []))}")
            
            # Notify subscribers (for WebSocket implementation)
            for callback in self.subscribers:
                callback(processed_data)
                
        except Exception as e:
            self.logger.error(f"❌ Data update failed: {e}")
        finally:
            self.is_updating = False

# Initialize real-time manager
data_manager = RealTimeDataManager()

# API Routes
@app.route('/')
def serve_dashboard():
    """Serve the main SOC dashboard"""
    return send_from_directory('static', 'index.html')

@app.route('/search-analytics')
def serve_search_analytics():
    """Serve the Search & Analytics dashboard"""
    return send_from_directory('static', 'search-analytics.html')

@app.route('/fim')
def serve_fim():
    """Serve the FIM dashboard"""
    return send_from_directory('static', 'fim.html')

@app.route('/uba')
def serve_uba():
    """Serve the UBA dashboard"""
    return send_from_directory('static', 'uba.html')

@app.route('/threat-intel')
def serve_threat_intel():
    """Serve the Threat Intelligence dashboard"""
    return send_from_directory('static', 'threat-intel.html')

@app.route('/vulnerability-discovery')
def serve_vulnerability_discovery():
    """Serve the Vulnerability Discovery dashboard"""
    return send_from_directory('static', 'vulnerability-discovery.html')

@app.route('/case-management')
def serve_case_management():
    """Serve the Case Management dashboard"""
    return send_from_directory('static', 'case-management.html')



"""@app.route('/api/dashboard-data')
def get_dashboard_data():
    "Get comprehensive dashboard data - FIXED VERSION"
    try:
        time_range = request.args.get('time_range', 'today')
        hours = int(request.args.get('hours', 24))
        size = int(request.args.get('size', 1000))
        
        logging.info(f"📊 Dashboard data requested - time_range: {time_range}, hours: {hours}, size: {size}")
        
        # Always use the same method for consistency
        raw_alerts = wazuh_client.get_alerts_last_x_hours(hours=hours, size=size)
        
        query_info = {
            'time_range': time_range,
            'hours': hours,
            'size': size,
            'query_time': datetime.now().isoformat(),
            'query_method': 'get_alerts_last_x_hours'
        }
        
        processed_data = data_processor.process_alerts_for_dashboard(raw_alerts, query_info)
        
        # Clear cache for this specific query to ensure fresh data on next request
        cache_key = f"alerts_last_{hours}_hours_{size}"
        if cache_key in wazuh_client._cache:
            del wazuh_client._cache[cache_key]
            logging.debug(f"🧹 Cleared cache for key: {cache_key}")
        
        # Add detailed query info to response
        processed_data['query_info'] = query_info
        processed_data['cache_info'] = {
            'cache_cleared': True,
            'cache_key': cache_key
        }
        
        logging.info(f"✅ Dashboard data prepared - Alerts: {len(processed_data.get('alerts', []))}, Total hits: {processed_data.get('result_metadata', {}).get('total_hits', 0)}")
        
        return jsonify(processed_data)
        
    except Exception as e:
        logging.error(f"❌ Dashboard data error: {e}", exc_info=True)
        return jsonify({"error": str(e), "query_info": {"error_time": datetime.now().isoformat()}}), 500""" 


"""@app.route('/api/dashboard-data')
def get_dashboard_data():
    "Get comprehensive dashboard data with PROPER time range filtering"
    try:
        # ✅ Get time range parameters correctly
        time_range = request.args.get('time_range', '24')
        start_time = request.args.get('start')
        end_time = request.args.get('end')
        size = int(request.args.get('size', 1000))

        logging.info(f"📊 Dashboard data requested - time_range: {time_range}, start: {start_time}, end: {end_time}")

        # ✅ Determine time range based on parameters
        if time_range == 'custom' and start_time and end_time:
            # Custom date range from frontend
            # Format: YYYY-MM-DDTHH:mm (from datetime-local input)
            raw_alerts = wazuh_client.get_alerts_by_time_range(
                start_time=start_time,
                end_time=end_time,
                size=size
            )
            query_info = {
                'time_range': 'custom',
                'start': start_time,
                'end': end_time,
                'size': size,
                'query_time': datetime.now().isoformat(),
                'query_method': 'get_alerts_by_time_range'
            }
            logging.info(f"📊 Using custom time range: {start_time} to {end_time}")
            
        else:
            # Standard time ranges (1h, 6h, 24h, 7d)
            hours_map = {
                '1': 1,      # Last 1 hour
                '6': 6,      # Last 6 hours
                '24': 24,    # Last 24 hours (default)
                '168': 168   # Last 7 days (24*7)
            }
            hours = hours_map.get(time_range, 24)  # Default to 24 hours
            
            raw_alerts = wazuh_client.get_alerts_last_x_hours(
                hours=hours, 
                size=size
            )
            query_info = {
                'time_range': time_range,
                'hours': hours,
                'size': size,
                'query_time': datetime.now().isoformat(),
                'query_method': 'get_alerts_last_x_hours'
            }
            logging.info(f"📊 Using standard time range: last {hours} hours")

        processed_data = data_processor.process_alerts_for_dashboard(raw_alerts, query_info)

        # ✅ Clear cache for this specific query to ensure fresh data
        cache_key = f"alerts_last_{hours}_hours_{size}" if time_range != 'custom' else f"alerts_{start_time}_{end_time}_{size}"
        if cache_key in wazuh_client._cache:
            del wazuh_client._cache[cache_key]
            logging.debug(f"🧹 Cleared cache for key: {cache_key}")

        # ✅ Add detailed query info to response
        processed_data['query_info'] = query_info
        processed_data['cache_info'] = {
            'cache_cleared': True,
            'cache_key': cache_key
        }

        logging.info(f"✅ Dashboard data prepared - Alerts: {len(processed_data.get('alerts', []))}, Total hits: {processed_data.get('result_metadata', {}).get('total_hits', 0)}")

        return jsonify(processed_data)

    except Exception as e:
        logging.error(f"❌ Dashboard data error: {e}", exc_info=True)
        return jsonify({
            "error": str(e), 
            "query_info": {
                "error_time": datetime.now().isoformat(),
                "time_range": time_range,
                "start": start_time,
                "end": end_time
            }
        }), 500"""

"""@app.route('/api/dashboard-data')
def get_dashboard_data():
    "Get comprehensive dashboard data with OPTIMIZED time range filtering"
    try:
        # ✅ Get time range parameters correctly
        time_range = request.args.get('time_range', '24')
        start_time = request.args.get('start')
        end_time = request.args.get('end')
        size = int(request.args.get('size', 1000))

        logging.info(f"📊 Dashboard data requested - time_range: {time_range}")

        # ✅ OPTIMIZATION: Different size limits for different time ranges
        size_map = {
            '1': 500,    # 1 hour - smaller size
            '6': 800,    # 6 hours - medium size
            '24': 1000,  # 24 hours - normal size
            '168': 1500  # 7 days - larger size
        }
        
        size = size_map.get(time_range, 1000)

        # ✅ Determine time range based on parameters
        if time_range == 'custom' and start_time and end_time:
            # Custom date range
            raw_alerts = wazuh_client.get_alerts_by_time_range(
                start_time=start_time,
                end_time=end_time,
                size=size
            )
            query_method = 'get_alerts_by_time_range'
            hours = None
            
        else:
            # Standard time ranges
            hours_map = {
                '1': 1,      # Last 1 hour
                '6': 6,      # Last 6 hours
                '24': 24,    # Last 24 hours
                '168': 168   # Last 7 days
            }
            hours = hours_map.get(time_range, 24)
            
            # ✅ OPTIMIZATION: Use smaller size for longer time ranges
            raw_alerts = wazuh_client.get_alerts_last_x_hours_optimized(
                hours=hours, 
                size=size
            )
            query_method = 'get_alerts_last_x_hours_optimized'

        # ✅ Fast processing with minimal data
        processed_data = data_processor.process_alerts_for_dashboard_fast(raw_alerts, {
            'time_range': time_range,
            'hours': hours,
            'size': size,
            'query_time': datetime.now().isoformat(),
            'query_method': query_method
        })

        logging.info(f"✅ Fast dashboard data prepared - Alerts: {len(processed_data.get('alerts', []))}")

        return jsonify(processed_data)

    except Exception as e:
        logging.error(f"❌ Dashboard data error: {e}")
        return jsonify({
            "error": str(e), 
            "query_info": {"error_time": datetime.now().isoformat()}
        }), 500"""

"""@app.route('/api/dashboard-data')
def get_dashboard_data():
    "Get comprehensive dashboard data with PROPER time range filtering"
    try:
        # ✅ Get time range parameters correctly
        time_range = request.args.get('time_range', '24')
        start_time = request.args.get('start')
        end_time = request.args.get('end')
        
        # Default size to 500 for performance
        size = int(request.args.get('size', 500))

        logging.info(f"📊 Dashboard data requested - time_range: {time_range}")

        # ✅ Determine time range based on parameters
        if time_range == 'custom' and start_time and end_time:
            # Custom date range from frontend
            # Format: YYYY-MM-DDTHH:mm (from datetime-local input)
            raw_alerts = wazuh_client.get_alerts_by_time_range(
                start_time=start_time,
                end_time=end_time,
                size=size
            )
            query_method = 'get_alerts_by_time_range'
            hours = None
            query_desc = f"Custom: {start_time} to {end_time}"
            
        else:
            # Standard time ranges (1h, 6h, 24h, 7d)
            hours_map = {
                '1': 1,      # Last 1 hour
                '6': 6,      # Last 6 hours
                '24': 24,    # Last 24 hours (default)
                '168': 168   # Last 7 days (24*7)
            }
            hours = hours_map.get(time_range, 24)  # Default to 24 hours

            raw_alerts = wazuh_client.get_alerts_last_x_hours(
                hours=hours,
                size=size
            )
            query_method = 'get_alerts_last_x_hours'
            query_desc = f"Last {hours} hours"

        # ✅ Process data
        processed_data = data_processor.process_alerts_for_dashboard(raw_alerts, {
            'time_range': time_range,
            'hours': hours,
            'size': size,
            'start_time': start_time,
            'end_time': end_time,
            'query_time': datetime.now().isoformat(),
            'query_method': query_method,
            'query_description': query_desc
        })

        # ✅ Add debug info
        processed_data['debug_info'] = {
            'frontend_time_range': time_range,
            'backend_hours_used': hours,
            'query_size': size,
            'total_alerts_found': processed_data.get('summary', {}).get('total_alerts', 0),
            'processing_time': datetime.now().isoformat()
        }

        logging.info(f"✅ Data prepared: {processed_data.get('summary', {}).get('total_alerts', 0)} alerts for {query_desc}")

        return jsonify(processed_data)

    except Exception as e:
        logging.error(f"❌ ERROR in dashboard-data: {e}", exc_info=True)
        return jsonify({
            "error": str(e),
            "debug_info": {
                "time_range_received": request.args.get('time_range'),
                "start_received": request.args.get('start'),
                "end_received": request.args.get('end'),
                "error_time": datetime.now().isoformat()
            }
        }), 500"""


@app.route('/api/dashboard-data')
def get_dashboard_data():
    """Get comprehensive dashboard data with PROPER time range filtering - FIXED VERSION"""
    try:
        # Get ALL parameters from frontend
        time_range = request.args.get('time_range', '24')
        start_time = request.args.get('start')
        end_time = request.args.get('end')
        force_refresh = request.args.get('force_refresh', 'false').lower() == 'true'
        
        # Get size parameter with defaults based on time range
        size_map = {
            '1': 300,    # 1 hour
            '6': 500,    # 6 hours
            '24': 800,   # 24 hours (your current data)
            '168': 1500  # 7 days
        }
        size = int(request.args.get('size', size_map.get(time_range, 800)))
        
        logging.info(f"📊 Dashboard data requested - time_range: {time_range}, start: {start_time}, end: {end_time}, size: {size}")

        # Force cache clearing if requested
        if force_refresh:
            cache_keys_to_clear = []
            for key in list(wazuh_client._cache.keys()):
                if 'alerts_last' in key or 'alerts_' in key:
                    cache_keys_to_clear.append(key)
            for key in cache_keys_to_clear:
                del wazuh_client._cache[key]
            logging.info(f"🧹 Force cleared {len(cache_keys_to_clear)} cache entries")

        # DETERMINE QUERY METHOD BASED ON TIME RANGE
        query_info = {
            'time_range': time_range,
            'size': size,
            'query_time': datetime.now().isoformat(),
            'force_refresh': force_refresh
        }
        
        if time_range == 'custom' and start_time and end_time:
            # Custom time range - ensure proper format
            if 'T' in start_time and 'T' in end_time:
                # Format: YYYY-MM-DDTHH:mm
                query_start = start_time
                query_end = end_time
            else:
                # Format without T, add it
                query_start = f"{start_time}T00:00:00" if len(start_time) == 10 else start_time
                query_end = f"{end_time}T23:59:59" if len(end_time) == 10 else end_time
            
            raw_alerts = wazuh_client.get_alerts_by_time_range(
                start_time=query_start,
                end_time=query_end,
                size=size
            )
            query_info.update({
                'query_method': 'get_alerts_by_time_range',
                'start_time': query_start,
                'end_time': query_end
            })
            logging.info(f"📊 Using CUSTOM time range: {query_start} to {query_end}")
            
        else:
            # Standard time ranges (1h, 6h, 24h, 7d)
            hours_map = {
                '1': 1,      # Last 1 hour
                '6': 6,      # Last 6 hours
                '24': 24,    # Last 24 hours
                '168': 168   # Last 7 days
            }
            hours = hours_map.get(time_range, 24)
            
            # Generate unique cache key for this specific query
            cache_key = f"alerts_last_{hours}_hours_{size}_{datetime.now().strftime('%Y%m%d%H')}"
            
            # Clear previous cache for different time ranges
            for key in list(wazuh_client._cache.keys()):
                if key.startswith('alerts_last_') and key != cache_key:
                    del wazuh_client._cache[key]
            
            raw_alerts = wazuh_client.get_alerts_last_x_hours(
                hours=hours,
                size=size
            )
            query_info.update({
                'query_method': 'get_alerts_last_x_hours',
                'hours': hours,
                'cache_key': cache_key
            })
            logging.info(f"📊 Using STANDARD time range: last {hours} hours, cache_key: {cache_key}")

        # Process data
        processed_data = data_processor.process_alerts_for_dashboard(raw_alerts, query_info)
        
        # Add verification data
        processed_data['verification'] = {
            'frontend_params': {
                'time_range_received': time_range,
                'start_received': start_time,
                'end_received': end_time,
                'size_requested': request.args.get('size')
            },
            'backend_actual': {
                'query_method_used': query_info.get('query_method'),
                'hours_used': query_info.get('hours'),
                'actual_size': size,
                'cache_status': 'cleared' if force_refresh else 'active'
            },
            'data_metrics': {
                'total_alerts_found': processed_data.get('summary', {}).get('total_alerts', 0),
                'alerts_returned': len(processed_data.get('alerts', [])),
                'time_range_display': f"Last {query_info.get('hours', '24')} hours" if 'hours' in query_info else f"Custom: {query_info.get('start_time', '')} to {query_info.get('end_time', '')}",
                'processing_timestamp': datetime.now().isoformat()
            }
        }
        
        # Add cache information
        processed_data['cache_info'] = {
            'cache_keys_cleared': cache_keys_to_clear if force_refresh else [],
            'current_cache_size': len(wazuh_client._cache),
            'current_cache_keys': list(wazuh_client._cache.keys())[:5]  # First 5 keys
        }

        logging.info(f"✅ Data prepared: {processed_data.get('summary', {}).get('total_alerts', 0)} alerts found")
        return jsonify(processed_data)

    except Exception as e:
        logging.error(f"❌ ERROR in dashboard-data: {e}", exc_info=True)
        return jsonify({
            "error": str(e),
            "debug_info": {
                "time_range_received": request.args.get('time_range'),
                "start_received": request.args.get('start'),
                "end_received": request.args.get('end'),
                "error_time": datetime.now().isoformat()
            }
        }), 500


@app.route('/api/alerts')
def get_alerts():
    """Get alerts with advanced filtering"""
    try:
        # Extract filter parameters
        severity = request.args.get('severity')
        agent = request.args.get('agent')
        search = request.args.get('search')
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 50))
        hours = int(request.args.get('hours', 24))
        size = int(request.args.get('size', 1000))
        
        logging.info(f"🔍 Alerts requested - hours: {hours}, size: {size}, filters: severity={severity}, agent={agent}")
        
        # Build query based on filters - use the consistent method
        raw_alerts = wazuh_client.get_alerts_last_x_hours(hours=hours, size=size)
        query_info = {
            'method': 'get_alerts',
            'hours': hours,
            'size': size,
            'filters': {'severity': severity, 'agent': agent, 'search': search},
            'query_time': datetime.now().isoformat()
        }
        
        processed_data = data_processor.process_alerts_for_dashboard(raw_alerts, query_info)
        
        # Apply filters
        filtered_alerts = processed_data['alerts']
        if severity:
            filtered_alerts = [a for a in filtered_alerts if a['severity'] >= int(severity)]
        if agent:
            filtered_alerts = [a for a in filtered_alerts if agent.lower() in a['agent_name'].lower()]
        if search:
            filtered_alerts = [
                a for a in filtered_alerts 
                if search.lower() in a['rule_description'].lower() or 
                   search.lower() in a['agent_name'].lower() or
                   search.lower() in str(a.get('groups', []))
            ]
        
        # Pagination
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        paginated_alerts = filtered_alerts[start_idx:end_idx]
        
        response = {
            'alerts': paginated_alerts,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': len(filtered_alerts),
                'pages': (len(filtered_alerts) + per_page - 1) // per_page
            },
            'time_range': f'last {hours} hours',
            'query_info': query_info,
            'filter_info': {
                'applied_filters': {
                    'severity': severity,
                    'agent': agent,
                    'search': search
                },
                'total_filtered': len(filtered_alerts),
                'total_original': len(processed_data['alerts'])
            }
        }
        
        logging.info(f"✅ Alerts response - Filtered: {len(filtered_alerts)}, Paginated: {len(paginated_alerts)}")
        return jsonify(response)
        
    except Exception as e:
        logging.error(f"❌ Alerts error: {e}", exc_info=True)
        return jsonify({"error": str(e)}), 500

@app.route('/api/severity-summary')
def get_severity_summary():
    """Get severity level summary"""
    try:
        summary = wazuh_client.get_severity_summary()
        return jsonify(summary)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/mitre-coverage')
def get_mitre_coverage():
    """Get MITRE ATT&CK coverage"""
    try:
        coverage = wazuh_client.get_mitre_coverage()
        return jsonify(coverage)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/health')
def health_check():
    """Comprehensive health check"""
    try:
        # Test Wazuh connectivity
        test_alerts = wazuh_client.get_alerts_last_x_hours(hours=1, size=10)
        is_healthy = 'error' not in test_alerts
        
        return jsonify({
            "status": "healthy" if is_healthy else "unhealthy",
            "timestamp": datetime.now().isoformat(),
            "components": {
                "wazuh_connection": is_healthy,
                "data_processor": True,
                "api_endpoints": True
            },
            "version": "1.0.0",
            "uptime": "0",
            "cache_info": {
                "cache_size": len(wazuh_client._cache),
                "cache_enabled": True
            }
        })
    except Exception as e:
        return jsonify({"status": "unhealthy", "error": str(e)}), 500

# Add a debug endpoint to test Wazuh queries
@app.route('/api/debug/wazuh-query')
def debug_wazuh_query():
    """Debug endpoint to test Wazuh queries"""
    try:
        hours = int(request.args.get('hours', 24))
        size = int(request.args.get('size', 10))
        
        # Test different query methods
        results = {
            "method_get_alerts_last_x_hours": wazuh_client.get_alerts_last_x_hours(hours=hours, size=size),
            "test_query_info": {
                "hours": hours,
                "size": size,
                "timestamp": datetime.now().isoformat()
            }
        }
        
        # Also show sample alert structure
        if results["method_get_alerts_last_x_hours"] and 'hits' in results["method_get_alerts_last_x_hours"]:
            hits = results["method_get_alerts_last_x_hours"]['hits']['hits']
            if hits:
                first_alert = hits[0]['_source']
                results["sample_alert_structure"] = {
                    "timestamp": first_alert.get('@timestamp'),
                    "rule_description": first_alert.get('rule', {}).get('description'),
                    "rule_groups": first_alert.get('rule', {}).get('groups'),
                    "location": first_alert.get('location'),
                    "agent": first_alert.get('agent', {}).get('name'),
                    "severity": first_alert.get('rule', {}).get('level')
                }
        
        return jsonify(results)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/clear-cache')
def clear_cache():
    """Clear Wazuh client cache"""
    try:
        cache_size = len(wazuh_client._cache)
        wazuh_client._cache.clear()
        logging.info(f"🧹 Cache cleared - Previously had {cache_size} entries")
        
        return jsonify({
            "status": "success",
            "message": f"Cache cleared (had {cache_size} entries)",
            "timestamp": datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/test-misp-in-alerts')
def test_misp_in_alerts():
    """Test endpoint to check if MISP alerts exist in the data"""
    try:
        hours = int(request.args.get('hours', 168))  # 7 days by default
        size = int(request.args.get('size', 1000))
        
        # Get alerts from Wazuh using consistent method
        raw_alerts = wazuh_client.get_alerts_last_x_hours(hours=hours, size=size)
        
        if not raw_alerts or 'hits' not in raw_alerts:
            return jsonify({"error": "No alerts found", "total": 0, "misp_alerts": []})
        
        total_hits = raw_alerts['hits']['total']['value']
        actual_hits = len(raw_alerts['hits']['hits'])
        
        # Look for MISP alerts
        misp_alerts = []
        for hit in raw_alerts['hits']['hits']:
            source = hit.get('_source', {})
            rule = source.get('rule', {})
            data = source.get('data', {})
            
            # Check various patterns for MISP alerts
            is_misp = False
            misp_pattern = ""
            
            # Check rule.groups
            rule_groups = rule.get('groups', [])
            if isinstance(rule_groups, list):
                for group in rule_groups:
                    if 'misp' in str(group).lower():
                        is_misp = True
                        misp_pattern = f"rule.groups: {group}"
                        break
            
            # Check rule.description
            rule_desc = rule.get('description', '')
            if 'MISP' in rule_desc.upper():
                is_misp = True
                misp_pattern = f"rule.description contains MISP"
            
            # Check data.misp field
            if isinstance(data, dict) and 'misp' in data:
                is_misp = True
                misp_pattern = f"data.misp field exists"
            
            # Check location
            location = source.get('location', '')
            if 'misp' in location.lower():
                is_misp = True
                misp_pattern = f"location: {location}"
            
            if is_misp:
                misp_alerts.append({
                    'id': hit.get('_id'),
                    'timestamp': source.get('@timestamp'),
                    'rule_description': rule_desc,
                    'rule_groups': rule_groups,
                    'location': location,
                    'data': data,
                    'misp_pattern': misp_pattern
                })
        
        return jsonify({
            'total_alerts': total_hits,
            'actual_returned': actual_hits,
            'misp_alerts_found': len(misp_alerts),
            'misp_alerts': misp_alerts,
            'time_range_hours': hours,
            'test_time': datetime.now().isoformat(),
            'query_method': 'get_alerts_last_x_hours'
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Background data updater
def background_data_updater():
    """Update data in background at regular intervals"""
    while True:
        try:
            data_manager.update_data()
            time.sleep(config.REFRESH_INTERVAL)
        except Exception as e:
            logging.error(f"❌ Background update error: {e}")
            time.sleep(60)  # Wait longer on error

# Start background thread
if config.ENABLE_REALTIME:
    updater_thread = threading.Thread(target=background_data_updater, daemon=True)
    updater_thread.start()

if __name__ == '__main__':
    logging.info("🚀 Starting Professional SOC Dashboard with Enhanced Debug Logging...")
    print(f"📊 Server running at: http://{Config.FLASK_HOST}:{Config.FLASK_PORT}")
    print("Press CTRL+C to stop the server")
    print(f"Debug mode: {Config.FLASK_DEBUG}")
    print(f"Refresh interval: {config.REFRESH_INTERVAL}s")
    app.run(
        host=Config.FLASK_HOST, 
        port=Config.FLASK_PORT, 
        debug=Config.FLASK_DEBUG
    )
