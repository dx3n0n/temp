from flask import Blueprint, jsonify, request
import requests
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import urllib3
import os
import re

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Configure logging
logger = logging.getLogger(__name__)

# Create blueprint
threat_intel_bp = Blueprint('threat_intel', __name__)

class ThreatIntelClient:
    """Threat Intelligence client for MISP and Wazuh integration"""
    
    def __init__(self, wazuh_client=None, misp_url: Optional[str] = None, misp_api_key: Optional[str] = None, verify_ssl: bool = False):
        self.wazuh_client = wazuh_client
        # Read MISP config from parameters or environment
        self.misp_url = misp_url or os.getenv('MISP_URL', 'https://127.0.0.1:9443')
        self.misp_api_key = misp_api_key or os.getenv('MISP_API_KEY', 'cNP4rjRBcxbFIwbYKICAjSn8PYpPKsg6bYJdb9z7')
        
        # Setup MISP session
        self.misp_session = requests.Session()
        if self.misp_api_key and self.misp_api_key.strip():
            self.misp_session.headers.update({
                'Authorization': self.misp_api_key,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            })
        else:
            self.misp_session.headers.update({
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            })
        
        # SSL verification
        self.misp_session.verify = verify_ssl
        
        self.misp_timeout = int(os.getenv('MISP_TIMEOUT', '30'))
        
        # Cache for feeds
        self._feeds_cache = None
        self._feeds_cache_time = None
        self._cache_timeout = int(os.getenv('MISP_CACHE_TIMEOUT', '300'))
        
        logger.info(f"✅ Threat Intelligence client initialized with MISP URL: {self.misp_url}")

    def get_threat_feeds(self, days: int = 30, page_size: int = 100) -> Dict[str, Any]:
        """Get MISP threat intelligence feeds from LAST 30 DAYS with ALL attributes/IoCs"""
        try:
            # Calculate timestamp for X days ago
            from datetime import datetime, timedelta
            days_ago = datetime.now() - timedelta(days=days)
            timestamp_filter = int(days_ago.timestamp())
            
            # Check cache first
            cache_key = f"feeds_{days}_{timestamp_filter}"
            if (self._feeds_cache and self._feeds_cache_time and 
                self._feeds_cache.get('cache_key') == cache_key and
                (datetime.now() - self._feeds_cache_time).total_seconds() < self._cache_timeout):
                logger.info("🔄 Returning cached threat feeds")
                return self._feeds_cache
            
            # Test MISP connectivity
            if not self._test_misp_connection():
                logger.error(f"❌ MISP connection failed to {self.misp_url}")
                return {"error": "Cannot connect to MISP server", "events": [], "summary": self._get_empty_feeds_summary()}
            
            # Get ALL events from last X days - fetch page by page
            events_url = f"{self.misp_url}/events/index"
            all_events = []
            current_page = 1
            max_pages = 10  # Limit to prevent too many requests
            
            logger.info(f"🔍 Fetching MISP events from last {days} days (timestamp >= {timestamp_filter})")
            
            while current_page <= max_pages:
                params = {
                    'limit': page_size,
                    'page': current_page,
                    'sort': 'timestamp',
                    'direction': 'desc',
                    'published': 1,
                    'withAttachments': 0,
                    'timestamp': f'{timestamp_filter}',
                }
                
                logger.info(f"🔍 Fetching threat feeds page {current_page} from MISP")
                response = self.misp_session.get(events_url, params=params, timeout=self.misp_timeout)
                
                if response.status_code != 200:
                    logger.error(f"❌ MISP API returned status {response.status_code}: {response.text[:200]}")
                    break
                
                events_data = response.json()
                
                # Process events based on MISP response format
                page_events = []
                if isinstance(events_data, list):
                    page_events = events_data
                elif isinstance(events_data, dict):
                    if 'response' in events_data:
                        page_events = events_data['response']
                    else:
                        # Try to extract events from the root level
                        page_events = [v for k, v in events_data.items() if isinstance(v, dict) and 'id' in v]
                else:
                    logger.warning(f"⚠️ Unexpected MISP response format: {type(events_data)}")
                    page_events = []
                
                if not page_events:
                    logger.info(f"✅ No more events found at page {current_page}")
                    break
                
                # Filter events by date (ensure they're within our time range)
                filtered_page_events = []
                for event in page_events:
                    event_timestamp = event.get('timestamp', '0')
                    if isinstance(event_timestamp, str):
                        try:
                            event_timestamp = int(event_timestamp)
                        except:
                            event_timestamp = 0
                    
                    # Check if event is within our time range
                    if event_timestamp >= timestamp_filter:
                        filtered_page_events.append(event)
                
                all_events.extend(filtered_page_events)
                
                logger.info(f"✅ Page {current_page}: Found {len(filtered_page_events)} events (total: {len(all_events)})")
                
                # Check if we got fewer events than requested - means no more pages
                if len(page_events) < page_size:
                    logger.info(f"✅ Reached last page (got {len(page_events)} events, requested {page_size})")
                    break
                
                current_page += 1
                if current_page > max_pages:
                    logger.warning(f"⚠️ Reached maximum page limit of {max_pages}")
                    break
            
            if not all_events:
                logger.warning(f"⚠️ No events from last {days} days returned from MISP")
                return {"events": [], "summary": self._get_empty_feeds_summary()}
            
            # Process events for display - get full event details WITH ALL ATTRIBUTES
            processed_events = []
            logger.info(f"🔍 Processing {len(all_events)} events for display...")
            
            for i, event_data in enumerate(all_events):
                event_id = event_data.get('id')
                if not event_id:
                    continue
                
                # Log progress every 10 events
                if i % 10 == 0:
                    logger.info(f"🔍 Processing event {i+1}/{len(all_events)} (ID: {event_id})")
                    
                processed_event = self._get_full_event_details(event_id)
                if processed_event:
                    processed_events.append(processed_event)
            
            # If we couldn't get events, return empty
            if not processed_events:
                logger.warning("⚠️ No events processed from MISP response")
                return {"events": [], "summary": self._get_empty_feeds_summary()}
            
            # Sort by timestamp descending (newest first)
            processed_events.sort(key=lambda x: int(x.get('timestamp', 0)), reverse=True)
            
            # Get summary statistics
            summary = self._get_feeds_summary(processed_events)
            
            result = {
                "events": processed_events,
                "total": len(processed_events),
                "summary": summary,
                "cache_key": cache_key,
                "days": days,
                "timestamp_filter": timestamp_filter
            }
            
            # Cache the result
            self._feeds_cache = result
            self._feeds_cache_time = datetime.now()
            
            logger.info(f"✅ Retrieved {len(processed_events)} threat feeds from last {days} days with {sum(e.get('attribute_count', 0) for e in processed_events)} total IoCs")
            return result
            
        except requests.exceptions.Timeout:
            logger.error("❌ MISP request timed out")
            return {"error": "MISP server timeout", "events": [], "summary": self._get_empty_feeds_summary()}
        except requests.exceptions.ConnectionError:
            logger.error("❌ MISP connection error")
            return {"error": "Cannot connect to MISP server", "events": [], "summary": self._get_empty_feeds_summary()}
        except Exception as e:
            logger.error(f"❌ Failed to get threat feeds: {e}", exc_info=True)
            return {"error": str(e), "events": [], "summary": self._get_empty_feeds_summary()}

    def _test_misp_connection(self) -> bool:
        """Test if MISP server is reachable"""
        try:
            # Try multiple endpoints
            endpoints = [
                f"{self.misp_url}/servers/getPyMISPVersion.json",
                f"{self.misp_url}/events",
                f"{self.misp_url}/attributes"
            ]
            
            for endpoint in endpoints:
                try:
                    response = self.misp_session.get(endpoint, params={'limit': 1}, timeout=10)
                    if response.status_code == 200:
                        logger.info(f"✅ MISP connection successful to {endpoint}")
                        return True
                except:
                    continue
            
            logger.error("❌ All MISP endpoints failed")
            return False
            
        except Exception as e:
            logger.error(f"❌ MISP connection test failed: {e}")
            return False

    def _get_full_event_details(self, event_id: str) -> Optional[Dict[str, Any]]:
        """Get full event details from MISP with ALL attributes/IoCs"""
        try:
            # Get event with ALL attributes
            event_url = f"{self.misp_url}/events/{event_id}"
            params = {
                'includeAttachments': 0,
                'includeAllTags': 1,
                'includeAttributeUuid': 1,
                'includeFeedCorrelations': 1,
                'includeDecayScore': 0,
                'includeCorrelations': 1,
                'includeEventCorrelations': 1,
                'includeWarninglistHits': 0,
                'enforceWarninglist': 0
            }
            
            response = self.misp_session.get(event_url, params=params, timeout=self.misp_timeout)
            
            if response.status_code != 200:
                logger.warning(f"⚠️ Failed to get details for event {event_id}: {response.status_code}")
                return None
            
            event_data = response.json()
            
            # Extract event data based on MISP API structure
            if 'Event' in event_data:
                event_data = event_data['Event']
            
            # Get basic event info
            processed_event = {
                'id': event_id,
                'info': event_data.get('info', 'Untitled Event'),
                'date': event_data.get('date', ''),
                'timestamp': event_data.get('timestamp', ''),
                'threat_level_id': str(event_data.get('threat_level_id', '1')),
                'analysis': str(event_data.get('analysis', '0')),
                'description': event_data.get('description', 'No description available.'),
                'published': bool(event_data.get('published', False)),
                'org_id': event_data.get('org_id', ''),
                'orgc_id': event_data.get('orgc_id', ''),
                'uuid': event_data.get('uuid', ''),
                'event_creator_email': event_data.get('event_creator_email', '')
            }
            
            # Get ALL attributes (IoCs)
            attributes = []
            if 'Attribute' in event_data:
                attributes = event_data.get('Attribute', [])
            
            # Process ALL attributes
            all_attributes = []
            for attr in attributes:
                if isinstance(attr, dict):
                    attribute_data = {
                        'id': attr.get('id', ''),
                        'uuid': attr.get('uuid', ''),
                        'type': attr.get('type', 'unknown'),
                        'value': attr.get('value', ''),
                        'category': attr.get('category', ''),
                        'to_ids': bool(attr.get('to_ids', False)),
                        'comment': attr.get('comment', ''),
                        'timestamp': attr.get('timestamp', ''),
                        'first_seen': attr.get('first_seen', ''),
                        'last_seen': attr.get('last_seen', '')
                    }
                    
                    # Add tags if available
                    if 'Tag' in attr:
                        attribute_data['tags'] = [tag.get('name', '') for tag in attr.get('Tag', []) if tag.get('name')]
                    
                    all_attributes.append(attribute_data)
            
            processed_event['attributes'] = all_attributes
            processed_event['attribute_count'] = len(all_attributes)
            
            # Get event tags
            tags = []
            if 'Tag' in event_data:
                tags = [tag.get('name', '') for tag in event_data.get('Tag', []) if tag.get('name')]
            elif 'tags' in event_data:
                tags = [tag for tag in event_data.get('tags', []) if tag]
            
            processed_event['tags'] = tags[:10]
            
            return processed_event
            
        except Exception as e:
            logger.error(f"❌ Error getting full event details for {event_id}: {e}")
            return None

    def _get_feeds_summary(self, events: List[Dict]) -> Dict[str, Any]:
        """Get comprehensive summary from processed events"""
        try:
            total_events = len(events)
            total_attributes = sum(event.get('attribute_count', 0) for event in events)
            
            # Count by attribute type
            attribute_types = {}
            for event in events:
                for attr in event.get('attributes', []):
                    attr_type = attr.get('type', 'unknown')
                    attribute_types[attr_type] = attribute_types.get(attr_type, 0) + 1
            
            # Count by category
            categories = {}
            for event in events:
                for attr in event.get('attributes', []):
                    category = attr.get('category', 'uncategorized')
                    categories[category] = categories.get(category, 0) + 1
            
            # Count threat levels
            threat_levels = {'1': 0, '2': 0, '3': 0, '4': 0}
            for event in events:
                level = event.get('threat_level_id', '1')
                threat_levels[level] = threat_levels.get(level, 0) + 1
            
            # Count analysis status
            analysis_status = {'0': 0, '1': 0, '2': 0}
            for event in events:
                analysis = event.get('analysis', '0')
                analysis_status[analysis] = analysis_status.get(analysis, 0) + 1
            
            # Get date range
            timestamps = [int(e.get('timestamp', 0)) for e in events if e.get('timestamp')]
            if timestamps:
                oldest = datetime.fromtimestamp(min(timestamps)).strftime('%Y-%m-%d')
                newest = datetime.fromtimestamp(max(timestamps)).strftime('%Y-%m-%d')
            else:
                oldest = newest = 'N/A'
            
            summary = {
                'total_events': total_events,
                'total_attributes': total_attributes,
                'unique_tags': len(set(tag for event in events for tag in event.get('tags', []))),
                'attribute_types': dict(sorted(attribute_types.items(), key=lambda x: x[1], reverse=True)[:10]),
                'categories': dict(sorted(categories.items(), key=lambda x: x[1], reverse=True)[:10]),
                'threat_levels': threat_levels,
                'analysis_status': analysis_status,
                'date_range': {
                    'oldest': oldest,
                    'newest': newest
                },
                'last_updated': datetime.now().isoformat()
            }
            
            return summary
                
        except Exception as e:
            logger.error(f"❌ Failed to get feeds summary: {e}")
            return self._get_empty_feeds_summary()

    def _get_empty_feeds_summary(self) -> Dict[str, Any]:
        return {
            'total_events': 0,
            'total_attributes': 0,
            'unique_tags': 0,
            'attribute_types': {},
            'categories': {},
            'threat_levels': {'1': 0, '2': 0, '3': 0, '4': 0},
            'analysis_status': {'0': 0, '1': 0, '2': 0},
            'date_range': {'oldest': 'N/A', 'newest': 'N/A'},
            'last_updated': datetime.now().isoformat()
        }

    def get_threat_alerts(self, start_time: str = None, end_time: str = None, size: int = 1000) -> Dict[str, Any]:
        """Get threat intelligence alerts from Wazuh (MISP IoC matches)"""
        if not self.wazuh_client:
            print("❌ DEBUG: Wazuh client not available!")
            logger.error("❌ Wazuh client not available")
            return {"alerts": [], "total": 0, "summary": {}}
        
        try:
            # Define time range - DEFAULT TO 7 DAYS since you said you have MISP alerts from 3-4 days ago
            if not start_time or not end_time:
                end_time = datetime.now().isoformat()
                start_time = (datetime.now() - timedelta(days=7)).isoformat()  # 7 days back
            
            print(f"🔍 DEBUG: Querying Wazuh for MISP alerts from {start_time} to {end_time}")
            logger.info(f"🔍 Querying Wazuh for MISP alerts from {start_time} to {end_time}")
            
            # Query specifically for MISP alerts based on the exact structure from your example
            # Your MISP alert has: rule.groups: ["misp", "misp_alert"], data.misp field, location: "misp"
            query = {
                "query": {
                    "bool": {
                        "must": [
                            {
                                "range": {
                                    "@timestamp": {
                                        "gte": start_time,
                                        "lte": end_time
                                    }
                                }
                            }
                        ],
                        "should": [
                            # Look for "misp" in rule.groups (array field)
                            {
                                "term": {
                                    "rule.groups": "misp"
                                }
                            },
                            {
                                "term": {
                                    "rule.groups": "misp_alert"
                                }
                            },
                            # Look for data.misp field existence
                            {
                                "exists": {
                                    "field": "data.misp"
                                }
                            },
                            # Look for "MISP" in rule.description
                            {
                                "wildcard": {
                                    "rule.description": "*MISP*"
                                }
                            },
                            # Look for "misp" in location field
                            {
                                "term": {
                                    "location": "misp"
                                }
                            }
                        ],
                        "minimum_should_match": 1
                    }
                },
                "size": size,
                "sort": [{"@timestamp": {"order": "desc"}}],
                "_source": [
                    "rule.id",
                    "rule.description", 
                    "rule.level",
                    "rule.groups",
                    "agent.name",
                    "agent.id",
                    "agent.ip",
                    "@timestamp",
                    "data.misp",
                    "location",
                    "full_log",
                    "manager.name",
                    "id",
                    "decoder.name"
                ]
            }
            
            print(f"🔍 DEBUG: Sending MISP-specific query to Wazuh")
            logger.info(f"🔍 Sending MISP-specific query to Wazuh")
            
            result = self.wazuh_client._make_request("wazuh-alerts-4.x-*/_search", query)
            
            if 'error' in result:
                print(f"❌ DEBUG: Wazuh query failed: {result['error']}")
                logger.error(f"❌ Wazuh query failed: {result['error']}")
                return {"alerts": [], "total": 0, "summary": {}}
            
            if 'hits' not in result:
                print("❌ DEBUG: No 'hits' in Wazuh response!")
                logger.error("❌ No 'hits' in Wazuh response")
                return {"alerts": [], "total": 0, "summary": {}}
            
            total_hits = result['hits']['total']['value']
            actual_hits = len(result['hits']['hits'])
            
            print(f"🔍 DEBUG: Wazuh returned {total_hits} MISP alerts total")
            print(f"🔍 DEBUG: Wazuh returned {actual_hits} MISP alerts actual hits")
            
            if actual_hits > 0:
                print(f"✅ DEBUG: Found MISP alerts! Showing first 3:")
                for i in range(min(3, actual_hits)):
                    hit = result['hits']['hits'][i]
                    source = hit.get('_source', {})
                    print(f"  Alert {i}:")
                    print(f"    ID: {hit.get('_id')}")
                    print(f"    Timestamp: {source.get('@timestamp')}")
                    print(f"    Rule description: {source.get('rule', {}).get('description')}")
                    print(f"    Rule groups: {source.get('rule', {}).get('groups', [])}")
                    print(f"    Location: {source.get('location', 'N/A')}")
                    print(f"    Data keys: {list(source.get('data', {}).keys())}")
                    if 'data' in source and 'misp' in source['data']:
                        print(f"    🎯 Found data.misp: {source['data']['misp']}")
            
            # Process the alerts
            processed_result = self._process_threat_alerts(result)
            print(f"✅ DEBUG: Processed {len(processed_result.get('alerts', []))} MISP alerts")
            
            return processed_result
            
        except Exception as e:
            print(f"❌ DEBUG: Exception in get_threat_alerts: {e}")
            logger.error(f"❌ Failed to get threat alerts: {e}", exc_info=True)
            return {"alerts": [], "total": 0, "summary": {}}

    def _process_threat_alerts(self, raw_alerts: Dict[str, Any]) -> Dict[str, Any]:
        """Process and enrich threat alerts from Wazuh"""
        try:
            if not raw_alerts or 'hits' not in raw_alerts:
                print("❌ DEBUG: No raw alerts data or hits missing in _process_threat_alerts")
                return {"alerts": [], "total": 0, "summary": {}}
            
            total_hits = raw_alerts['hits']['total']['value']
            actual_hits = len(raw_alerts['hits']['hits'])
            print(f"🔍 DEBUG: _process_threat_alerts: {total_hits} total, {actual_hits} actual")
            
            alerts_data = []
            ioc_types = {}
            severity_counts = {i: 0 for i in range(1, 16)}
            agent_alerts = {}
            categories = {}
            
            for i, hit in enumerate(raw_alerts['hits']['hits']):
                print(f"🔍 DEBUG: Processing MISP alert {i+1}/{actual_hits}")
                alert = self._process_single_alert(hit)
                if alert:
                    alerts_data.append(alert)
                    
                    # Update metrics
                    severity = alert['severity']
                    if severity in severity_counts:
                        severity_counts[severity] += 1
                    
                    agent_name = alert['agent_name']
                    agent_alerts[agent_name] = agent_alerts.get(agent_name, 0) + 1
                    
                    # Track IOC types
                    ioc_type = alert.get('ioc_type', 'unknown')
                    ioc_types[ioc_type] = ioc_types.get(ioc_type, 0) + 1
                    
                    # Track categories
                    category = alert.get('category', 'uncategorized')
                    categories[category] = categories.get(category, 0) + 1
            
            # Create summary
            summary = {
                'total_alerts': total_hits,
                'total_processed': len(alerts_data),
                'high_severity': sum(count for sev, count in severity_counts.items() if sev >= 8),
                'critical_alerts': sum(count for sev, count in severity_counts.items() if sev >= 12),
                'unique_agents': len(agent_alerts),
                'ioc_types': dict(sorted(ioc_types.items(), key=lambda x: x[1], reverse=True)[:10]),
                'categories': dict(sorted(categories.items(), key=lambda x: x[1], reverse=True)[:10]),
                'severity_distribution': {str(k): v for k, v in severity_counts.items() if v > 0},
                'top_agents': dict(sorted(agent_alerts.items(), key=lambda x: x[1], reverse=True)[:10]),
                'last_updated': datetime.now().isoformat()
            }
            
            print(f"✅ DEBUG: _process_threat_alerts completed: {len(alerts_data)} MISP alerts processed")
            return {
                "alerts": alerts_data,
                "total": total_hits,
                "summary": summary
            }
                
        except Exception as e:
            print(f"❌ DEBUG: Exception in _process_threat_alerts: {e}")
            logger.error(f"❌ Failed to process threat alerts: {e}", exc_info=True)
            return {"alerts": [], "total": 0, "summary": {}}

    def _process_single_alert(self, hit: Dict) -> Optional[Dict[str, Any]]:
        """Process a single threat alert"""
        try:
            source = hit.get('_source', {})
            rule = source.get('rule', {})
            agent = source.get('agent', {})
            data = source.get('data', {})
            
            print(f"🔍 DEBUG: Processing alert - Rule groups: {rule.get('groups', [])}")
            
            # Extract MISP information from the alert
            misp_data = {}
            category = 'Unknown'
            ioc_type = 'Unknown'
            ioc_value = ''
            event_id = ''
            source_desc = ''
            
            # Check for data.misp field
            if isinstance(data, dict) and 'misp' in data:
                misp_data = data.get('misp', {})
                print(f"🔍 DEBUG: Found data.misp: {misp_data}")
                if isinstance(misp_data, dict):
                    category = misp_data.get('category', 'Unknown')
                    ioc_type = misp_data.get('type', 'Unknown')
                    ioc_value = misp_data.get('value', '')
                    event_id = misp_data.get('event_id', '')
                    if isinstance(misp_data.get('source'), dict):
                        source_desc = misp_data.get('source', {}).get('description', '')
                    else:
                        source_desc = str(misp_data.get('source', ''))
            else:
                print(f"🔍 DEBUG: No data.misp field found, but alert matched MISP pattern")
            
            # If no misp data found, try to extract from rule description
            if not ioc_value and 'MISP' in rule.get('description', ''):
                # Try to extract from description
                desc = rule.get('description', '')
                print(f"🔍 DEBUG: Looking for IOC in description: {desc}")
                # Look for pattern: "Attribute: value"
                if 'Attribute:' in desc:
                    parts = desc.split('Attribute:')
                    if len(parts) > 1:
                        ioc_value = parts[1].strip().split(',')[0].strip()
                        print(f"🔍 DEBUG: Extracted IOC from description: {ioc_value}")
            
            alert = {
                'id': hit.get('_id', ''),
                'timestamp': source.get('@timestamp', ''),
                'severity': rule.get('level', 0),
                'rule_id': rule.get('id', ''),
                'rule_description': rule.get('description', ''),
                'agent_name': agent.get('name', 'Unknown'),
                'agent_ip': agent.get('ip', ''),
                'agent_id': agent.get('id', ''),
                'category': category,
                'ioc_type': ioc_type,
                'ioc_value': ioc_value,
                'misp_event_id': event_id,
                'source_description': source_desc,
                'location': source.get('location', ''),
                'full_log': source.get('full_log', '')[:500],  # Truncate for display
                'rule_groups': rule.get('groups', []),
                'manager': source.get('manager', {}).get('name', ''),
                'decoder': source.get('decoder', {}).get('name', ''),
                'raw_data': source  # Keep original for reference
            }
            
            print(f"✅ DEBUG: Processed MISP alert: {ioc_value} ({ioc_type})")
            return alert
            
        except Exception as e:
            print(f"❌ DEBUG: Exception in _process_single_alert: {e}")
            logger.error(f"❌ Error processing single alert: {e}")
            return None

# Initialize Threat Intelligence client placeholder
threat_intel_client = None

# API Routes
@threat_intel_bp.route('/api/threat-intel/feeds')
def get_threat_intel_feeds():
    """Get MISP threat intelligence feeds - FIXED VERSION with 30 days filter"""
    try:
        global threat_intel_client
        if not threat_intel_client:
            return jsonify({"error": "Threat intelligence client not initialized"}), 500
        
        # Get query parameters
        days = int(request.args.get('days', 30))
        limit = int(request.args.get('limit', 100))  # Overall limit
        
        logger.info(f"🔍 Fetching MISP feeds from last {days} days")
        
        # Get threat feeds from last X days
        result = threat_intel_client.get_threat_feeds(days=days)
        
        if 'error' in result:
            return jsonify({"error": result['error']}), 500
        
        events = result.get('events', [])
        summary = result.get('summary', {})
        
        # Apply additional filters if provided
        threat_level = request.args.get('threat_level')
        analysis = request.args.get('analysis')
        attribute_type = request.args.get('attribute_type')
        search_query = request.args.get('search', '').lower()
        
        filtered_events = events
        
        if threat_level:
            filtered_events = [event for event in filtered_events if str(event.get('threat_level_id', '1')) == threat_level]
        
        if analysis:
            filtered_events = [event for event in filtered_events if str(event.get('analysis', '0')) == analysis]
        
        if attribute_type:
            filtered_events = [
                event for event in filtered_events 
                if any(attr.get('type') == attribute_type for attr in event.get('attributes', []))
            ]
        
        if search_query:
            filtered_events = [
                event for event in filtered_events 
                if (search_query in event.get('info', '').lower() or 
                    search_query in event.get('description', '').lower() or
                    any(search_query in attr.get('value', '').lower() for attr in event.get('attributes', [])) or
                    any(search_query in tag.lower() for tag in event.get('tags', [])))
            ]
        
        # Apply overall limit
        if limit > 0 and limit < len(filtered_events):
            filtered_events = filtered_events[:limit]
        
        # Pagination
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', min(limit, 20)))
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        paginated_events = filtered_events[start_idx:end_idx]
        
        return jsonify({
            'events': paginated_events,
            'summary': summary,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': len(filtered_events),
                'pages': max(1, (len(filtered_events) + per_page - 1) // per_page)
            },
            'timestamp': datetime.now().isoformat(),
            'total_events': len(events),
            'total_filtered': len(filtered_events),
            'days': days,
            'date_range': summary.get('date_range', {})
        })
        
    except Exception as e:
        logger.error(f"❌ Threat intel feeds error: {e}", exc_info=True)
        return jsonify({"error": str(e)}), 500

@threat_intel_bp.route('/api/threat-intel/alerts')
def get_threat_intel_alerts():
    """Get threat intelligence alerts from Wazuh"""
    print(f"🔍 DEBUG: /api/threat-intel/alerts endpoint called")
    try:
        global threat_intel_client
        if not threat_intel_client:
            print("❌ DEBUG: Threat intelligence client not initialized!")
            return jsonify({
                'alerts': [],
                'summary': {},
                'timestamp': datetime.now().isoformat(),
                'error': 'Threat intelligence client not initialized'
            })
        
        print(f"✅ DEBUG: Threat intel client is initialized")
        
        # Get query parameters
        hours = int(request.args.get('hours', 168))  # Default to 7 days (168 hours)
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 50))
        ioc_type = request.args.get('ioc_type')
        category = request.args.get('category')
        min_severity = request.args.get('min_severity')
        agent = request.args.get('agent')
        search = request.args.get('search')
        
        print(f"🔍 DEBUG: Query params - hours: {hours}, page: {page}, per_page: {per_page}")
        
        # Calculate time range - use ISO format for the query
        end_time = datetime.now()
        start_time = end_time - timedelta(hours=hours)
        
        print(f"🔍 DEBUG: Time range - start: {start_time.isoformat()}, end: {end_time.isoformat()}")
        
        # Get threat alerts
        print(f"🔍 DEBUG: Calling threat_intel_client.get_threat_alerts()")
        result = threat_intel_client.get_threat_alerts(
            start_time=start_time.isoformat(),
            end_time=end_time.isoformat(),
            size=1000
        )
        
        alerts = result.get('alerts', [])
        summary = result.get('summary', {})
        
        print(f"🔍 DEBUG: Got {len(alerts)} MISP alerts from get_threat_alerts()")
        
        # Apply filters
        filtered_alerts = alerts
        
        if ioc_type:
            filtered_alerts = [alert for alert in filtered_alerts if alert.get('ioc_type') == ioc_type]
        
        if category:
            filtered_alerts = [alert for alert in filtered_alerts if alert.get('category') == category]
        
        if min_severity:
            min_sev = int(min_severity)
            filtered_alerts = [alert for alert in filtered_alerts if alert.get('severity', 0) >= min_sev]
        
        if agent:
            filtered_alerts = [alert for alert in filtered_alerts if agent.lower() in alert.get('agent_name', '').lower()]
        
        if search:
            search_lower = search.lower()
            filtered_alerts = [
                alert for alert in filtered_alerts 
                if (search_lower in alert.get('ioc_value', '').lower() or 
                    search_lower in alert.get('rule_description', '').lower() or
                    search_lower in alert.get('agent_name', '').lower() or
                    search_lower in alert.get('category', '').lower())
            ]
        
        # Pagination
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        paginated_alerts = filtered_alerts[start_idx:end_idx]
        
        print(f"✅ DEBUG: Returning {len(paginated_alerts)} paginated MISP alerts")
        
        return jsonify({
            'alerts': paginated_alerts,
            'summary': summary,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': len(filtered_alerts),
                'pages': max(1, (len(filtered_alerts) + per_page - 1) // per_page)
            },
            'timestamp': datetime.now().isoformat(),
            'time_range': {
                'start': start_time.isoformat(),
                'end': end_time.isoformat(),
                'hours': hours
            }
        })
        
    except Exception as e:
        print(f"❌ DEBUG: Exception in /api/threat-intel/alerts: {e}")
        logger.error(f"❌ Threat intel alerts error: {e}", exc_info=True)
        return jsonify({
            'alerts': [],
            'summary': {},
            'timestamp': datetime.now().isoformat(),
            'error': str(e)
        }), 500

@threat_intel_bp.route('/api/threat-intel/stats')
def get_threat_intel_stats():
    """Get comprehensive threat intelligence statistics"""
    try:
        global threat_intel_client
        if not threat_intel_client:
            return jsonify({
                'feeds': {},
                'alerts': {},
                'timestamp': datetime.now().isoformat()
            })
        
        # Get feeds stats (last 30 days)
        feeds_result = threat_intel_client.get_threat_feeds(days=30)
        feeds_summary = feeds_result.get('summary', threat_intel_client._get_empty_feeds_summary())
        
        # Get alerts stats (last 7 days)
        end_time = datetime.now()
        start_time = end_time - timedelta(days=7)
        alerts_result = threat_intel_client.get_threat_alerts(
            start_time=start_time.isoformat(),
            end_time=end_time.isoformat(),
            size=100
        )
        alerts_summary = alerts_result.get('summary', {})
        
        return jsonify({
            'feeds': feeds_summary,
            'alerts': alerts_summary,
            'timestamp': datetime.now().isoformat(),
            'status': 'ok'
        })
        
    except Exception as e:
        logger.error(f"❌ Threat intel stats error: {e}", exc_info=True)
        return jsonify({
            'feeds': {},
            'alerts': {},
            'timestamp': datetime.now().isoformat(),
            'error': str(e)
        }), 500

# Helper function to initialize the threat intelligence client
def init_threat_intel_client(wazuh_client=None):
    """Initialize the threat intelligence client using env variables"""
    global threat_intel_client
    misp_url = os.getenv('MISP_URL')
    misp_api_key = os.getenv('MISP_API_KEY')
    verify_ssl = os.getenv('MISP_VERIFY_SSL', 'false').lower() == 'true'
    
    threat_intel_client = ThreatIntelClient(
        wazuh_client=wazuh_client, 
        misp_url=misp_url, 
        misp_api_key=misp_api_key, 
        verify_ssl=verify_ssl
    )
    print(f"✅ DEBUG: Threat Intelligence client initialized with wazuh_client: {wazuh_client is not None}")
    logger.info("✅ Threat Intelligence client initialized")
