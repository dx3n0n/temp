# fim.py - File Integrity Monitoring Module - REAL DATA ONLY
from flask import Blueprint, jsonify, request
import logging
from datetime import datetime, timedelta
import os
from typing import Dict, List, Any

# Create Blueprint for FIM
fim_bp = Blueprint('fim', __name__)

logger = logging.getLogger(__name__)

class FIMDataProcessor:
    """Data processor for File Integrity Monitoring - REAL DATA ONLY"""
    
    @staticmethod
    def process_fim_events(raw_fim_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process FIM events for the dashboard - ONLY REAL DATA"""
        logging.debug("🔄 Processing FIM events")
        
        events = []
        data_source = 'wazuh'
        
        # Check if we have valid Wazuh response structure
        if not raw_fim_data:
            logging.warning("❌ No data received from Wazuh client")
            data_source = 'wazuh_empty'
        elif 'error' in raw_fim_data:
            logging.error(f"❌ Wazuh error: {raw_fim_data['error']}")
            data_source = 'wazuh_error'
        elif ('hits' in raw_fim_data and 
              raw_fim_data['hits']['total']['value'] > 0 and
              len(raw_fim_data['hits']['hits']) > 0):
            
            # Check if data is fake (contains sample IDs)
            hits = raw_fim_data['hits']['hits']
            if hits and any('fim-' in str(hit.get('_id', '')) for hit in hits):
                logging.error("❌ Detected SAMPLE data from Wazuh client! Check wazuh_client.py")
                logging.error("❌ IDs contain 'fim-' prefix - this is sample data")
                data_source = 'wazuh_sample_error'
            else:
                logging.info(f"✅ Processing {raw_fim_data['hits']['total']['value']} real FIM events from Wazuh")
                events = FIMDataProcessor.extract_fim_events_from_wazuh(raw_fim_data)
        else:
            logging.info("ℹ️ No FIM events found in the specified time range")
            data_source = 'wazuh_empty'
        
        # Calculate summary metrics
        summary = FIMDataProcessor.calculate_fim_summary(events)
        
        logging.info(f"✅ FIM Processing Complete: {len(events)} real events, source: {data_source}")
        
        return {
            'events': events,
            'summary': summary,
            'last_updated': datetime.now().isoformat(),
            'data_source': data_source
        }
    
    @staticmethod
    def extract_fim_events_from_wazuh(raw_fim_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract FIM events from REAL Wazuh response"""
        events = []
        hits = raw_fim_data['hits']['hits']
        
        for i, hit in enumerate(hits):
            source = hit.get('_source', {})
            
            # Skip if this is clearly sample data
            if 'fim-' in str(hit.get('_id', '')):
                logging.warning(f"⚠️ Skipping sample event with ID: {hit.get('_id')}")
                continue
                
            syscheck = source.get('syscheck', {})
            
            # Skip if no syscheck data (not a real FIM event)
            if not syscheck:
                continue
            
            event = {
                'id': hit.get('_id', ''),
                'timestamp': source.get('@timestamp', ''),
                'agent_name': source.get('agent', {}).get('name', 'Unknown'),
                'filename': FIMDataProcessor.extract_filename(syscheck.get('path', '')),
                'file_path': syscheck.get('path', ''),
                'change_type': FIMDataProcessor.determine_change_type(syscheck, source.get('rule', {})),
                'user': syscheck.get('uname_after', 'Unknown'),
                'severity': FIMDataProcessor.calculate_fim_severity(syscheck.get('path', ''), source.get('rule', {}).get('level', 0)),
                'file_size': syscheck.get('size', 'N/A'),
                'file_hash': syscheck.get('sha256_after', syscheck.get('md5_after', 'N/A')),
                'process_name': 'syscheck',
                'agent_ip': source.get('agent', {}).get('ip', 'N/A'),
                'os_name': source.get('agent', {}).get('os', {}).get('name', 'N/A'),
                'rule_id': source.get('rule', {}).get('id', ''),
                'rule_description': source.get('rule', {}).get('description', ''),
                'changed_attributes': syscheck.get('changed_attributes', []),
                'registry_path': 'HKEY' in syscheck.get('path', '') if syscheck.get('path') else False
            }
            
            # Add Windows permissions if available
            if syscheck.get('win_perm_after'):
                event['windows_permissions'] = syscheck.get('win_perm_after', [])
            
            # Add old permissions if available
            if syscheck.get('perm_before'):
                event['old_permissions'] = syscheck.get('perm_before')
                event['new_permissions'] = syscheck.get('perm_after', 'N/A')
            
            events.append(event)
            
            # Log first few events for debugging
            if i < 3:  # Log only first 3 events
                logging.debug(f"🔍 Real FIM event {i+1}: ID={event['id'][:20]}..., File={event['filename']}, Type={event['change_type']}")
        
        logging.info(f"✅ Extracted {len(events)} REAL FIM events from Wazuh")
        return events
    
    @staticmethod
    def extract_filename(path: str) -> str:
        """Extract filename from path"""
        if not path:
            return 'unknown'
        
        # Handle registry paths
        if path.startswith('HKEY_'):
            return path.split('\\')[-1] if '\\' in path else path
        
        # Handle file paths
        return os.path.basename(path)
    
    @staticmethod
    def determine_change_type(syscheck: Dict, rule: Dict) -> str:
        """Determine change type from syscheck data and rule description"""
        changed_attributes = syscheck.get('changed_attributes', [])
        rule_description = rule.get('description', '').lower()
        
        # Check for specific attribute changes first
        if 'perm' in changed_attributes:
            return 'permission'
        elif 'uid' in changed_attributes or 'gid' in changed_attributes:
            return 'ownership'
        elif 'mtime' in changed_attributes or 'ctime' in changed_attributes:
            return 'modified'
        elif 'size' in changed_attributes:
            return 'modified'
        
        # Fallback to rule description analysis
        if any(word in rule_description for word in ['added', 'created']):
            return 'created'
        elif any(word in rule_description for word in ['modified', 'changed']):
            return 'modified'
        elif any(word in rule_description for word in ['deleted', 'removed']):
            return 'deleted'
        
        # Default based on mode
        mode = syscheck.get('mode', '')
        if mode == 'realtime':
            return 'modified'
        elif mode == 'scheduled':
            return 'modified'
        
        return 'modified'  # Default fallback
    
    @staticmethod
    def calculate_fim_severity(file_path: str, rule_level: int) -> str:
        """Calculate severity based on file path and rule level"""
        path = (file_path or '').lower()
        
        # Critical files and registry keys
        critical_paths = [
            '/etc/passwd', '/etc/shadow', '/etc/sudoers', 
            'HKEY_LOCAL_MACHINE\\SAM', 'HKEY_LOCAL_MACHINE\\SECURITY',
            'HKEY_LOCAL_MACHINE\\SYSTEM', 'HKEY_LOCAL_MACHINE\\SOFTWARE'
        ]
        
        # Important system files
        system_paths = [
            '/etc/', '/bin/', '/sbin/', '/usr/bin/', '/usr/sbin/',
            'HKEY_LOCAL_MACHINE\\System', 'HKEY_LOCAL_MACHINE\\Windows'
        ]
        
        if any(critical in path for critical in critical_paths):
            return 'critical'
        elif any(system in path for system in system_paths):
            return 'high'
        elif rule_level >= 10:
            return 'high'
        elif rule_level >= 7:
            return 'medium'
        else:
            return 'low'
    
    @staticmethod
    def calculate_fim_summary(events: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate FIM summary metrics - REAL DATA ONLY"""
        if not events:
            return {
                'total_files': 0,
                'total_changes': 0,
                'suspicious_changes': 0,
                'monitored_agents': 0,
                'integrity_score': "100%",
                'last_scan': datetime.now().strftime("%Y-%m-%d %H:%M"),
                'total_files_trend': "0%",
                'changes_trend': "0%",
                'suspicious_trend': "0%",
                'agents_trend': "0%",
                'integrity_trend': "0%"
            }
        
        # Calculate real metrics from actual data
        total_files = len(set(event['file_path'] for event in events))
        total_changes = len(events)
        suspicious_changes = len([e for e in events if e['severity'] in ['high', 'critical']])
        monitored_agents = len(set(event['agent_name'] for event in events))
        
        # Calculate integrity score (higher is better)
        critical_changes = len([e for e in events if e['severity'] == 'critical'])
        integrity_score = max(0, 100 - (critical_changes * 2))
        
        # Get latest timestamp for last scan
        latest_time = None
        for event in events:
            if event.get('timestamp'):
                try:
                    event_time = datetime.fromisoformat(event['timestamp'].replace('Z', '+00:00'))
                    if latest_time is None or event_time > latest_time:
                        latest_time = event_time
                except:
                    continue
        
        last_scan = latest_time.strftime("%Y-%m-%d %H:%M") if latest_time else datetime.now().strftime("%Y-%m-%d %H:%M")
        
        return {
            'total_files': total_files,
            'total_changes': total_changes,
            'suspicious_changes': suspicious_changes,
            'monitored_agents': monitored_agents,
            'integrity_score': f"{integrity_score}%",
            'last_scan': last_scan,
            'total_files_trend': "0%",
            'changes_trend': "0%",
            'suspicious_trend': "0%",
            'agents_trend': "0%",
            'integrity_trend': "0%"
        }

# Initialize FIM processor
fim_processor = FIMDataProcessor()

# FIM Routes
@fim_bp.route('/api/fim/events')
def get_fim_events():
    """Get FIM events data - ONLY REAL DATA, NO SAMPLES"""
    logging.info("🔍 FIM events API called - REAL DATA ONLY")
    try:
        time_range = request.args.get('time_range', '24h')
        
        if time_range == '24h':
            start_time = (datetime.now() - timedelta(hours=24)).isoformat()
            end_time = datetime.now().isoformat()
        elif time_range == '30days':
            start_time = (datetime.now() - timedelta(days=30)).isoformat()
            end_time = datetime.now().isoformat()
        else:
            hours = int(request.args.get('hours', 24))
            end_time = datetime.now()
            start_time = end_time - timedelta(hours=hours)
        
        logging.info(f"🔍 Fetching REAL FIM events from {start_time} to {end_time}")
        
        # Import Wazuh client from main app
        from server import wazuh_client
        
        # Get data from Wazuh client
        raw_fim_data = wazuh_client.get_fim_events(start_time, end_time)
        
        # Log what we received
        if raw_fim_data:
            has_hits = 'hits' in raw_fim_data
            total = raw_fim_data.get('hits', {}).get('total', {}).get('value', 0) if has_hits else 0
            hits_count = len(raw_fim_data.get('hits', {}).get('hits', [])) if has_hits else 0
            logging.info(f"📊 Raw data stats: has_hits={has_hits}, total={total}, hits_count={hits_count}")
            
            # Check for sample data
            if hits_count > 0:
                first_id = raw_fim_data['hits']['hits'][0].get('_id', '')
                if 'fim-' in str(first_id):
                    logging.error("🚨 WARNING: Received SAMPLE data from wazuh_client.get_fim_events()")
                    logging.error("🚨 This indicates wazuh_client.py is generating fake data")
                    logging.error("🚨 Fix wazuh_client.py to get real OpenSearch/Wazuh data")
        else:
            logging.warning("⚠️ No data returned from wazuh_client.get_fim_events()")
        
        # Process the data
        processed_data = FIMDataProcessor.process_fim_events(raw_fim_data)
        
        # Add debug info
        processed_data['debug_info'] = {
            'raw_data_hits': len(raw_fim_data.get('hits', {}).get('hits', [])) if raw_fim_data else 0,
            'processed_events': len(processed_data['events']),
            'data_source': processed_data['data_source'],
            'time_range': f"{start_time} to {end_time}"
        }
        
        logging.info(f"✅ Returning {len(processed_data['events'])} REAL FIM events")
        return jsonify(processed_data)
        
    except Exception as e:
        logging.error(f"❌ FIM data error: {e}", exc_info=True)
        # Return empty data - NO SAMPLE DATA
        return jsonify({
            'events': [],
            'summary': FIMDataProcessor.calculate_fim_summary([]),
            'last_updated': datetime.now().isoformat(),
            'data_source': 'error',
            'error': str(e),
            'message': 'Wazuh client needs to be fixed for real data'
        })
