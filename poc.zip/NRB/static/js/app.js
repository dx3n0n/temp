/**
 * Professional SOC Dashboard - Main Application
 * Enterprise-grade Security Operations Center Dashboard
 */

class ProfessionalSOCDashboard {
    constructor() {
        this.config = {
            refreshInterval: 30000, // 30 seconds
            apiBaseUrl: '/api',
            maxAlerts: 5000,
            enableRealtime: true,
            /**refreshIntervals: {
                '1': 10000,     // 10 seconds for 1 hour
                '6': 15000,     // 15 seconds for 6 hours
                '24': 30000,    // 30 seconds for 24 hours
                '168': 60000,   // 60 seconds for 7 days
                'custom': 120000 // 120 seconds for custom range
            }*/

        };
        
        this.state = {
            alerts: [],
            filteredAlerts: [],
            currentPage: 1,
            itemsPerPage: 25,
            totalPages: 1,
            currentFilters: {
                search: '',
                severity: '',
                agent: '',
                timeRange: '24'
            },
            sortConfig: {
                key: 'timestamp',
                direction: 'desc'
            },
            charts: {},
            lastUpdate: null,
            isLoading: false,
         
        };
        this.requestCounter = 0;
        this.activeRequestId = 0;
        
        this.init();
    }

    /**
     * Initialize the dashboard
     */
    async init() {


          try {
            this.showLoading(true);

            // Initialize components
             this.initializeEventListeners();
             this.initializeCharts();
             this.initializeFilters();
             this.initializeSummaryCardEvents();

            // Set default dates for custom range
             this.setDefaultDates();

            // Load initial data
             await this.loadDashboardData(true);

            // Start auto-refresh based on current time range
             this.startAutoRefresh();

             this.updateLastRefreshTime();

             } catch (error) {
                console.error('Failed to initialize dashboard:', error);
                /*this.showError('Initialization failed: ' + error.message);*/
           } finally {
               this.showLoading(false);
           }
    }
 

/**
 * Adjust refresh interval based on current time range
 */
   
 
    /**
     * Initialize event listeners
     */
    initializeEventListeners() {

       // Refresh button
       /*document.getElementById('refreshBtn').addEventListener('click', () => {
           this.loadDashboardData();
        });*/
      const refreshBtn = document.getElementById('refreshBtn');
       if (refreshBtn) {
         refreshBtn.addEventListener('click', () => {
            console.log('🔄 Manual refresh requested');
            this.loadDashboardData(true);
         });
       }

       // Time range filter - WITH FORCE REFRESH
        /**document.getElementById('timeRangeFilter').addEventListener('change', (e) => {
            this.state.currentFilters.timeRange = e.target.value;
            this.toggleCustomDateRange();

        
        // Add force refresh parameter
            this.loadDashboardData(true); // true means force refresh
        });*/

       document.getElementById('timeRangeFilter').addEventListener('change', (e) => {
          const newTimeRange = e.target.value;
          console.log(`🔄 Time range changed from ${this.state.currentFilters.timeRange} to ${newTimeRange}`);
    
    // ✅ FIX: Clear data before loading new
          this.state.alerts = [];
          this.state.filteredAlerts = [];
          this.updateAlertsTable();
    
          this.state.currentFilters.timeRange = newTimeRange;
          this.toggleCustomDateRange();

    // Add force refresh parameter
          this.loadDashboardData(true); // true means force refresh
         });


       /**const timeRangeFilter = document.getElementById('timeRangeFilter');
          if (timeRangeFilter) {
             timeRangeFilter.addEventListener('change', (e) => {
             const newTimeRange = e.target.value;
             console.log(`🔄 Time range changed from ${this.state.currentFilters.timeRange} to ${newTimeRange}`);
            
            // ✅ FIX: Clear data before loading new
            this.state.alerts = [];
            this.state.filteredAlerts = [];
            this.updateAlertsTable();

            this.state.currentFilters.timeRange = newTimeRange;
            this.toggleCustomDateRange();

            // Add force refresh parameter
            this.loadDashboardData(true);
        });
    }*/
     // ✅ FIXED: Time range filter - SINGLE listener with cache busting
    /**const timeRangeFilter = document.getElementById('timeRangeFilter');
    if (timeRangeFilter) {
        timeRangeFilter.addEventListener('change', (e) => {
            const oldRange = this.state.currentFilters.timeRange;
            const newRange = e.target.value;
            
            console.log(`🔄 Time range changed: ${oldRange} → ${newRange}`);
            
            // ✅ Clear ALL data immediately
            this.state.alerts = [];
            this.state.filteredAlerts = [];
            this.state.currentPage = 1;
            
            // Update state
            this.state.currentFilters.timeRange = newRange;
            
            // Update UI
            this.toggleCustomDateRange();
            this.updateAlertsTable(); // Clear table view
            
            // ✅ Force refresh with PROPER cache busting
            this.loadDashboardData(true);
            
            // Show feedback
            this.showMessage(`Loading ${newRange}h data...`, 'info');
        });
    }*/

    // Custom date apply button
        /**const applyCustomDateBtn = document.getElementById('applyCustomDate');
        if (applyCustomDateBtn) {
        applyCustomDateBtn.addEventListener('click', () => {
            this.state.currentFilters.timeRange = 'custom';
            this.loadDashboardData(true);
        });
    }*/

    // Search input
        /**document.getElementById('searchInput').addEventListener('input', debounce((e) => {
             this.state.currentFilters.search = e.target.value.toLowerCase();
             this.applyFilters();
          }, 300));*/

       /**const searchInput = document.getElementById('searchInput');
       if (searchInput) {
          searchInput.addEventListener('input', debounce((e) => {
               this.state.currentFilters.search = e.target.value.toLowerCase();
               this.applyFilters();
        }, 300));
    }*/
    // Severity filter
         document.getElementById('severityFilter').addEventListener('change', (e) => {
            this.state.currentFilters.severity = e.target.value;
            this.applyFilters();
          });
      /**const severityFilter = document.getElementById('severityFilter');
      if (severityFilter) {
          severityFilter.addEventListener('change', (e) => {
              this.state.currentFilters.severity = e.target.value;
              this.applyFilters();
        });
     }*/

    // Agent filter
         document.getElementById('agentFilter').addEventListener('change', (e) => {
            this.state.currentFilters.agent = e.target.value;
            this.applyFilters();
          });
        /**const agentFilter = document.getElementById('agentFilter');
        if (agentFilter) {
            agentFilter.addEventListener('change', (e) => {
                this.state.currentFilters.agent = e.target.value;
                this.applyFilters();
        });
      }*/

    // Table sorting
            this.initializeTableSorting();

    // Pagination
            this.initializePagination();

    // Modal
         document.getElementById('closeModal').addEventListener('click', () => {
            this.closeModal();
         });
         /**const closeModalBtn = document.getElementById('closeModal');
         if (closeModalBtn) {
             closeModalBtn.addEventListener('click', () => {
                this.closeModal();
        });
      }*/

    // Export button
         document.getElementById('exportBtn').addEventListener('click', () => {
            this.exportAlerts();
         });

        /**const exportBtn = document.getElementById('exportBtn');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => {
                this.exportAlerts();
         });
        }*/

    // Settings button
         document.getElementById('settingsBtn').addEventListener('click', () => {
            this.showSettings();
         });
        /**const settingsBtn = document.getElementById('settingsBtn');
        if (settingsBtn) {
           settingsBtn.addEventListener('click', () => {
              this.showSettings();
         });
       }*/

    // Close modal on overlay click
         document.getElementById('alertModal').addEventListener('click', (e) => {
            if (e.target === e.currentTarget) {
              this.closeModal();
          }
       });
      /**const modal = document.getElementById('alertModal');
      if (modal) {
         modal.addEventListener('click', (e) => {
            if (e.target === e.currentTarget) {
                this.closeModal();
            }
         });
       }*/
    }


    handleTimeRangeChange(newTimeRange) {
        console.log(`⏱️ Time range changed to: ${newTimeRange}`);
        
        // Update state
        this.state.currentFilters.timeRange = newTimeRange;
        
        // Update UI
        document.getElementById('timeRangeFilter').value = newTimeRange;
        this.toggleCustomDateRange();
        
        // Load new data immediately
        this.loadDashboardData(true);
        
        // Restart auto-refresh with new interval
        this.restartAutoRefresh();
        
        // Update UI feedback
        this.showTimeRangeFeedback(newTimeRange);
    }
    /**
     * Start auto-refresh based on current time range
     */
    startAutoRefresh() {
        if (!this.state.isAutoRefreshEnabled) return;
        
        // Stop any existing timer
        this.stopAutoRefresh();
        
        const timeRange = this.state.currentFilters.timeRange;
        const interval = this.config.refreshIntervals[timeRange] || 30000;
        
        console.log(`🔄 Starting auto-refresh: ${interval/1000}s interval for ${timeRange}h`);
        
        this.state.refreshTimer = setInterval(() => {
            console.log(`🔄 Auto-refreshing for time range: ${timeRange}h`);
            this.loadDashboardData();
        }, interval);
        
        this.showMessage(`Auto-refresh enabled: ${interval/1000}s interval`, 'info');
    }

    /**
     * Stop auto-refresh
     */
    stopAutoRefresh() {
        if (this.state.refreshTimer) {
            clearInterval(this.state.refreshTimer);
            this.state.refreshTimer = null;
            console.log('🛑 Auto-refresh stopped');
        }
    }

    /**
     * Restart auto-refresh with current settings
     */
    restartAutoRefresh() {
        this.stopAutoRefresh();
        this.startAutoRefresh();
    }

    /**
     * Show feedback when time range changes
     */
    /**showTimeRangeFeedback(timeRange) {
        const interval = this.config.refreshIntervals[timeRange] || 30000;
        const timeText = this.getTimeRangeText(timeRange);
        
        this.showMessage(`Time range changed to ${timeText}. Auto-refresh: ${interval/1000}s`, 'success');
    }*/

    

    /**
     * Initialize summary card click events
     */
    initializeSummaryCardEvents() {
        // Total Alerts card
        document.getElementById('totalAlertsCard').addEventListener('click', () => {
            this.applyFilterFromSummaryCard('all');
        });

        /**const totalAlertsCard = document.getElementById('totalAlertsCard');
        if (totalAlertsCard) {
           totalAlertsCard.addEventListener('click', () => {
              this.applyFilterFromSummaryCard('all');
         });
       }*/


        // Critical Alerts card
        document.getElementById('criticalAlertsCard').addEventListener('click', () => {
            this.applyFilterFromSummaryCard('critical');
        });

       /**const criticalAlertsCard = document.getElementById('criticalAlertsCard');
       if (criticalAlertsCard) {
           criticalAlertsCard.addEventListener('click', () => {
              this.applyFilterFromSummaryCard('critical');
         });
       }*/

        // High Severity card
        document.getElementById('highSeverityCard').addEventListener('click', () => {
            this.applyFilterFromSummaryCard('high');
        });
       
        /**const highSeverityCard = document.getElementById('highSeverityCard');
        if (highSeverityCard) {
            highSeverityCard.addEventListener('click', () => {
               this.applyFilterFromSummaryCard('high');
         });
       }*/

         /**const activeAgentsCard = document.getElementById('activeAgentsCard');
         if (activeAgentsCard) {
              activeAgentsCard.addEventListener('click', () => {
            // optional action (future use)
               console.log('Active Agents card clicked');
          });
        }*/   

        // MITRE Techniques card
        document.getElementById('mitreCountCard').addEventListener('click', () => {
            this.applyFilterFromSummaryCard('mitre');
        });

       /**const mitreCountCard = document.getElementById('mitreCountCard');
       if (mitreCountCard) {
          mitreCountCard.addEventListener('click', () => {
             this.applyFilterFromSummaryCard('mitre');
        });
      }*/

        
    }

    /**
     * Apply filter when summary card is clicked
     */
    applyFilterFromSummaryCard(filterType) {
        // Reset all filters first
        this.state.currentFilters = {
            search: '',
            severity: '',
            agent: '',
            timeRange: '24'
        };

        // Reset UI elements
        document.getElementById('searchInput').value = '';
        document.getElementById('severityFilter').value = '';
        document.getElementById('agentFilter').value = '';
        document.getElementById('timeRangeFilter').value = '24';
        
        // Hide custom date range
        document.getElementById('customDateRange').style.display = 'none';

        // Apply specific filter based on card clicked
        switch(filterType) {
            case 'all':
                // Show all alerts (no filters)
                break;
                
            case 'critical':
                // Filter for Critical alerts (12-15)
                this.state.currentFilters.severity = '12';
                document.getElementById('severityFilter').value = '12';
                break;
                
            case 'high':
                // Filter for High alerts (8-11)
                this.state.currentFilters.severity = '8';
                document.getElementById('severityFilter').value = '8';
                break;
                
            case 'agents':
                // For agents, we could filter by a specific agent or show agent-focused view
                // For now, let's just show all alerts but you can customize this
                this.showMessage('Agent filtering coming soon!', 'info');
                return;
                
            case 'mitre':
                // For MITRE, we could filter for alerts with MITRE tactics
                // Let's search for "mitre" in the search box
                this.state.currentFilters.search = 'mitre';
                document.getElementById('searchInput').value = 'mitre';
                break;
                
            
        }

        // Apply the filters
        this.applyFilters();
        
        // Scroll to alerts table
        this.scrollToAlertsTable();
        
        // Show feedback message
        this.showFilterFeedback(filterType);
    }


    /**
     * Scroll to alerts table section
     */
    scrollToAlertsTable() {
        const alertsSection = document.querySelector('.alerts-section');
        
        if (alertsSection) {
            alertsSection.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    /**
     * Show feedback message for filter application
     */
    showFilterFeedback(filterType) {
        const messages = {
            'all': 'Showing all alerts',
            'critical': 'Filtered for Critical alerts (Severity 12-15)',
            'high': 'Filtered for High alerts (Severity 8-11)',
            'mitre': 'Searching for alerts with MITRE ATT&CK tactics'
        };
        
        if (messages[filterType]) {
            this.showMessage(messages[filterType], 'success');
        }
    }

    /**
     * Initialize table sorting
     */
    initializeTableSorting() {
        const headers = document.querySelectorAll('.alerts-table th[data-sort]');
        headers.forEach(header => {
            header.style.cursor = 'pointer';
            header.addEventListener('click', () => {
                const sortKey = header.getAttribute('data-sort');
                this.sortTable(sortKey, header);
            });
        });
    }

    /**
     * Initialize pagination
     */
    initializePagination() {
        document.getElementById('firstPage').addEventListener('click', () => {
            this.goToPage(1);
        });

        document.getElementById('prevPage').addEventListener('click', () => {
            this.goToPage(this.state.currentPage - 1);
        });

        document.getElementById('nextPage').addEventListener('click', () => {
            this.goToPage(this.state.currentPage + 1);
        });

        document.getElementById('lastPage').addEventListener('click', () => {
            this.goToPage(this.state.totalPages);
        });
    }

    /**
     * Toggle custom date range visibility
     */
    toggleCustomDateRange() {
        const customRange = document.getElementById('customDateRange');
        if (this.state.currentFilters.timeRange === 'custom') {
            customRange.style.display = 'flex';
        } else {
            customRange.style.display = 'none';
        }
    }

    /**
     * Load dashboard data
     */
  


  async loadDashboardData(forceRefresh = false) {
    /**try {
        this.showLoading(true);

        const timeRange = this.state.currentFilters.timeRange;
        console.log(`⏱️ Loading data for time range: ${timeRange}, Force refresh: ${forceRefresh}`);

        // Validate time range value
        const validTimeRanges = ['1', '6', '24', '168', 'custom'];
        if (!validTimeRanges.includes(timeRange)) {
            console.warn(`⚠️ Invalid time range: ${timeRange}, defaulting to 24`);
            this.state.currentFilters.timeRange = '24';
        }

        // Build URL with verified parameters
        let url = `${this.config.apiBaseUrl}/dashboard-data?time_range=${this.state.currentFilters.timeRange}`;
        
        // Add force refresh if requested
        if (forceRefresh) {
            url += '&force_refresh=true';
            console.log('🔄 Force refresh requested');
        }
        
        // Add timestamp to prevent browser caching
        url += `&_t=${Date.now()}`;

        // Handle custom date range
        if (this.state.currentFilters.timeRange === 'custom') {
            const startDateInput = document.getElementById('startDate');
            const endDateInput = document.getElementById('endDate');
            
            if (startDateInput && endDateInput) {
                const startDate = startDateInput.value;
                const endDate = endDateInput.value;
                
                if (startDate && endDate) {
                    // Ensure proper format for backend
                    const start = startDate.includes('T') ? startDate : `${startDate}T00:00:00`;
                    const end = endDate.includes('T') ? endDate : `${endDate}T23:59:59`;
                    
                    url += `&start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`;
                    
                    console.log(`📅 Custom range: ${start} to ${end}`);
                } else {
                    this.showError('Please select both start and end dates for custom range');
                    this.showLoading(false);
                    return;
                }
            }
        }

        console.log(`🔗 Fetching from URL: ${url}`);

        // Make API call
        const response = await fetch(url);

        if (!response.ok) {
            const errorText = await response.text();
            console.error(`❌ Server error ${response.status}:`, errorText);
            throw new Error(`HTTP ${response.status}: ${errorText.substring(0, 100)}`);
        }

        const data = await response.json();

        // Check for errors in response
        if (data.error) {
            console.error('❌ Server returned error:', data.error);
            throw new Error(data.error);
        }

        // Log detailed information for debugging
        console.group('📊 Data Load Details');
        console.log('Time range requested:', timeRange);
        console.log('Total alerts received:', data.alerts?.length || 0);
        console.log('Summary data:', data.summary);
        
        if (data.verification) {
            console.log('Verification data:', data.verification);
            console.log('Actual hours used:', data.verification.backend_actual?.hours_used);
        }
        
        if (data.debug_info) {
            console.log('Debug info:', data.debug_info);
        }
        console.groupEnd();

        // Update state
        this.state.alerts = data.alerts || [];
        this.state.lastUpdate = new Date();

        // Update UI components
        this.updateSummaryCards(data.summary || {});
        this.updateCharts(data.charts || {});

        this.applyFilters();
        this.updateLastRefreshTime();

        // Show success message with time range info
        const timeRangeText = this.getTimeRangeText ? this.getTimeRangeText(timeRange) : `${timeRange} hours`;
        this.showMessage(`Loaded ${this.state.alerts.length} alerts for ${timeRangeText}`, 'success');

    } catch (error) {
        console.error('❌ Failed to load dashboard data:', error);
        this.showError('Failed to load data: ' + error.message);
    } finally {
        this.showLoading(false);
    }*/

     try {

          const requestId = ++this.requestCounter;
          this.activeRequestId = requestId;

          console.log(
            `📡 Request ${requestId} started for ${this.state.currentFilters.timeRange}h`
          );

          this.showLoading(true);

          const timeRange = this.state.currentFilters.timeRange;
          console.log(`⏱️ Loading data for time range: ${timeRange}, Force refresh: ${forceRefresh}`);

        // Validate time range value
          const validTimeRanges = ['1', '6', '24', '168', 'custom'];
          if (!validTimeRanges.includes(timeRange)) {
            console.warn(`⚠️ Invalid time range: ${timeRange}, defaulting to 24`);
            this.state.currentFilters.timeRange = '24';
        }

        // ✅ FIX 1: ALWAYS use unique URL for different time ranges
          /**let url = `${this.config.apiBaseUrl}/dashboard-data?time_range=${this.state.currentFilters.timeRange}`;
        
        // ✅ FIX 2: ALWAYS add cache busting parameter
        // Use combination of timestamp and timeRange to ensure unique URL for each range
          const cacheBuster = `t=${Date.now()}&range=${timeRange}`;
          url += `&${cacheBuster}`;

        // ✅ FIX 3: Clear previous alerts before loading new ones
          this.state.alerts = [];
          this.state.filteredAlerts = [];
          this.updateAlertsTable(); // Clear table immediately

        // Add force refresh if requested
          if (forceRefresh) {
             url += '&force_refresh=true';
             console.log('🔄 Force refresh requested');
           }*/

          /*let url = `${this.config.apiBaseUrl}/dashboard-data?time_range=${timeRange}`;*/
         // ✅ FIXED: Create UNIQUE URL with MULTIPLE cache busters
           let url = `${this.config.apiBaseUrl}/dashboard-data?time_range=${timeRange}`;
        
        // ✅ FIXED: Add MULTIPLE cache busting parameters
           // ✅ FIXED: Add aggressive cache busting
           const timestamp = Date.now();
           const random = Math.floor(Math.random() * 1000000);
           url += `&_=${timestamp}&cache_buster=${random}&time_range_key=${timeRange}`;
        
           if (forceRefresh) {
             url += '&force_refresh=true';
           }

        // Handle custom date range
          if (this.state.currentFilters.timeRange === 'custom') {
             const startDateInput = document.getElementById('startDate');
             const endDateInput = document.getElementById('endDate');

            if (startDateInput && endDateInput) {
                const startDate = startDateInput.value;
                const endDate = endDateInput.value;

                if (startDate && endDate) {
                    // Ensure proper format for backend
                    const start = startDate.includes('T') ? startDate : `${startDate}T00:00:00`;
                    const end = endDate.includes('T') ? endDate : `${endDate}T23:59:59`;

                    url += `&start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`;

                    console.log(`📅 Custom range: ${start} to ${end}`);
                } else {
                    this.showError('Please select both start and end dates for custom range');
                    this.showLoading(false);
                    return;
                }
            }
        }

        console.log(`🔗 Fetching from URL: ${url}`);

        // ✅ FIX 4: Disable browser caching completely
        /**const fetchOptions = {
            method: 'GET',
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0'
            },
            cache: 'no-store' // Modern fetch cache option
        };*/

        // ✅ FIXED: Disable ALL browser caching
        const fetchOptions = {
            method: 'GET',
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0'
            },
            cache: 'no-store'
        };
         // ✅ FIXED: Disable ALL caching mechanisms
        /**const fetchOptions = {
            method: 'GET',
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0',
                'X-No-Cache': 'true'
            },
            cache: 'no-store',
            credentials: 'same-origin'
        };*/



        // Make API call
        const response = await fetch(url, fetchOptions);

        if (!response.ok) {
            const errorText = await response.text();
            console.error(`❌ Server error ${response.status}:`, errorText);
            throw new Error(`HTTP ${response.status}: ${errorText.substring(0, 100)}`);
        }

        const data = await response.json();

        if (requestId !== this.activeRequestId) {
            console.warn(`🚫 Ignored stale response: request ${requestId}`);
            return;
        }

        // Check for errors in response
        if (data.error) {
            console.error('❌ Server returned error:', data.error);
            throw new Error(data.error);
        }

        // Log detailed information for debugging
        console.group('📊 Data Load Details');
        console.log('Time range requested:', timeRange);
        console.log('Total alerts received:', data.alerts?.length || 0);
        console.log('Summary data:', data.summary);

        if (data.verification) {
            console.log('Verification data:', data.verification);
            console.log('Actual hours used:', data.verification.backend_actual?.hours_used);
        }

        if (data.debug_info) {
            console.log('Debug info:', data.debug_info);
        }
        console.groupEnd();

        // Update state
       /** this.state.alerts = data.alerts || [];
        this.state.lastUpdate = new Date();

        // Update UI components
        this.updateSummaryCards(data.summary || {});
        this.updateCharts(data.charts || {});

        this.applyFilters();
        this.updateLastRefreshTime();

        // Show success message with time range info
        const timeRangeText = this.getTimeRangeText ? this.getTimeRangeText(timeRange) : `${timeRange} hours`;
        this.showMessage(`Loaded ${this.state.alerts.length} alerts for ${timeRangeText}`, 'success');

        // ✅ FIX 5: Log time range verification
        console.log(`✅ Time range verification: Requested ${timeRange}h, Got ${data.alerts?.length || 0} alerts`);

      } catch (error) {
        console.error('❌ Failed to load dashboard data:', error);
        this.showError('Failed to load data: ' + error.message);
      } finally {
        this.showLoading(false);
      }*/

      // ✅ FIXED: Clear old data before setting new
          /**this.state.alerts = [];
          this.state.filteredAlerts = [];
        
        // Set new data
          this.state.alerts = data.alerts || [];
          this.state.lastUpdate = new Date();
        
          console.log(`✅ Loaded ${this.state.alerts.length} alerts for ${timeRange}h range`);*/

          // ✅ FIXED: VERIFY data is for correct time range
        console.log(`✅ Received ${data.alerts?.length || 0} alerts for ${timeRange}h`);
        
        // ✅ Clear OLD data before setting NEW
        this.state.alerts = [];
        this.state.filteredAlerts = [];
        
        // Set new data
        this.state.alerts = data.alerts || [];
        this.state.lastUpdate = new Date();
        
        console.log(`✅ Set ${this.state.alerts.length} alerts in state for ${timeRange}h`);

        // Update UI
          this.updateSummaryCards(data.summary || {});
          this.updateCharts(data.charts || {});
          this.applyFilters();
          this.updateLastRefreshTime();

        } catch (error) {
           console.error('❌ Failed to load dashboard data:', error);
           this.showError('Failed to load data: ' + error.message);
        } finally {
           this.showLoading(false);
      }


   }

    /**
     * Apply filters to alerts
     */

   applyFilters() {
       let filtered = this.state.alerts.filter(alert => {
         if (!alert) return false;
        
        // Search filter with null checks
         const matchesSearch = !this.state.currentFilters.search ||
            (alert.rule_description && alert.rule_description.toLowerCase().includes(this.state.currentFilters.search)) ||
            (alert.agent_name && alert.agent_name.toLowerCase().includes(this.state.currentFilters.search)) ||
            (alert.rule_id && alert.rule_id.toLowerCase().includes(this.state.currentFilters.search)) ||
            (alert.mitre_tactics && alert.mitre_tactics.some(tactic =>
                tactic && tactic.toLowerCase().includes(this.state.currentFilters.search)
            ));

        // Severity filter
         const matchesSeverity = !this.state.currentFilters.severity ||
            (() => {
                const severityValue = parseInt(this.state.currentFilters.severity);
                const alertSeverity = parseInt(alert.severity) || 0;
                
                if (severityValue >= 12 && severityValue <= 15) {
                    return alertSeverity >= 12 && alertSeverity <= 15;
                } else if (severityValue >= 8 && severityValue <= 11) {
                    return alertSeverity >= 8 && alertSeverity <= 11;
                } else if (severityValue >= 4 && severityValue <= 7) {
                    return alertSeverity >= 4 && alertSeverity <= 7;
                } else if (severityValue >= 1 && severityValue <= 3) {
                    return alertSeverity >= 1 && alertSeverity <= 3;
                }
                return alertSeverity >= severityValue;
            })();

        // Agent filter
         const matchesAgent = !this.state.currentFilters.agent ||
            alert.agent_name === this.state.currentFilters.agent;

         return matchesSearch && matchesSeverity && matchesAgent;
    });

    // Apply sorting
      filtered = this.sortAlerts(filtered, this.state.sortConfig.key, this.state.sortConfig.direction);

      this.state.filteredAlerts = filtered;
      this.state.currentPage = 1;
      this.updateAlertsTable();
      this.updatePagination();
  }
    /**applyFilters() {
        let filtered = this.state.alerts.filter(alert => {
            // Search filter
            const matchesSearch = !this.state.currentFilters.search || 
                alert.rule_description.toLowerCase().includes(this.state.currentFilters.search) ||
                alert.agent_name.toLowerCase().includes(this.state.currentFilters.search) ||
                alert.rule_id.toLowerCase().includes(this.state.currentFilters.search) ||
                (alert.mitre_tactics && alert.mitre_tactics.some(tactic => 
                    tactic.toLowerCase().includes(this.state.currentFilters.search)
                ));
            
            // Severity filter - UPDATED for range-based filtering
            const matchesSeverity = !this.state.currentFilters.severity || 
                (() => {
                    const severityValue = parseInt(this.state.currentFilters.severity);
                    const alertSeverity = alert.severity;
                    
                    // Range-based matching (1-3: Low, 4-7: Medium, 8-11: High, 12-15: Critical)
                    if (severityValue >= 12 && severityValue <= 15) {
                        return alertSeverity >= 12 && alertSeverity <= 15;
                    } else if (severityValue >= 8 && severityValue <= 11) {
                        return alertSeverity >= 8 && alertSeverity <= 11;
                    } else if (severityValue >= 4 && severityValue <= 7) {
                        return alertSeverity >= 4 && alertSeverity <= 7;
                    } else if (severityValue >= 1 && severityValue <= 3) {
                        return alertSeverity >= 1 && alertSeverity <= 3;
                    } else {
                        // Fallback for values outside 1-15
                        return alertSeverity >= severityValue;
                    }
                })();
            
            // Agent filter
            const matchesAgent = !this.state.currentFilters.agent || 
                alert.agent_name === this.state.currentFilters.agent;
            
            return matchesSearch && matchesSeverity && matchesAgent;
        });
        
        // Apply sorting
        filtered = this.sortAlerts(filtered, this.state.sortConfig.key, this.state.sortConfig.direction);
        
        this.state.filteredAlerts = filtered;
        this.state.currentPage = 1;
        this.updateAlertsTable();
        this.updatePagination();
    }*/

    /**
     * Sort alerts array
     */
    sortAlerts(alerts, key, direction) {
        return alerts.sort((a, b) => {
            let aValue = a[key];
            let bValue = b[key];
            
            // Handle different data types
            if (key === 'timestamp') {
                aValue = new Date(aValue);
                bValue = new Date(bValue);
            } else if (key === 'severity') {
                aValue = parseInt(aValue);
                bValue = parseInt(bValue);
            }
            
            if (aValue < bValue) return direction === 'asc' ? -1 : 1;
            if (aValue > bValue) return direction === 'asc' ? 1 : -1;
            return 0;
        });
    }

    /**
     * Sort table
     */
    sortTable(key, header) {
        // Remove existing sort classes
        document.querySelectorAll('.alerts-table th[data-sort]').forEach(h => {
            h.classList.remove('sort-asc', 'sort-desc');
        });
        
        // Toggle direction or set new sort
        if (this.state.sortConfig.key === key) {
            this.state.sortConfig.direction = this.state.sortConfig.direction === 'asc' ? 'desc' : 'asc';
        } else {
            this.state.sortConfig.key = key;
            this.state.sortConfig.direction = 'desc';
        }
        
        // Add sort class to header
        header.classList.add(`sort-${this.state.sortConfig.direction}`);
        
        // Apply sorting
        this.applyFilters();
    }

    /**
     * Update alerts table
     */
    updateAlertsTable() {
        const tbody = document.getElementById('alertsTableBody');
        const startIndex = (this.state.currentPage - 1) * this.state.itemsPerPage;
        const endIndex = startIndex + this.state.itemsPerPage;
        const pageAlerts = this.state.filteredAlerts.slice(startIndex, endIndex);
        
        tbody.innerHTML = '';

        if (pageAlerts.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center" style="padding: 3rem;">
                        <i class="fas fa-search" style="font-size: 2rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                        <div>No alerts found matching your criteria</div>
                    </td>
                </tr>
            `;
            return;
        }

        pageAlerts.forEach(alert => {
            const row = this.createAlertRow(alert);
            tbody.appendChild(row);
        });
    }

    /**
     * Create alert table row
     */
    createAlertRow(alert) {
        const row = document.createElement('tr');
        row.className = `priority-${this.getSeverityLevel(alert.severity)}`;
        
        const severityClass = this.getSeverityClass(alert.severity);
        const timestamp = new Date(alert.timestamp).toLocaleString();
        
        row.innerHTML = `
            <td class="font-mono"  style="font-size: 0.75rem;">${timestamp}</td>
            <td>
                <span class="severity-badge ${severityClass}">
                    Level ${alert.severity}
                </span>
            </td>
            <td>
                <div class="font-medium">${alert.agent_name}</div>
                <div class="text-secondary" style="font-size: 0.75rem;">${alert.agent_ip}</div>
            </td>
            <td>
                <div class="font-medium">${alert.rule_description}</div>
                <div class="text-secondary" style="font-size: 0.75rem;">Groups: ${alert.groups.join(', ')}</div>
            </td>
            <td class="font-mono" style="font-size: 0.75rem;">${alert.rule_id}</td>
            <td>
                ${alert.mitre_tactics?.length ? 
                    alert.mitre_tactics.slice(0, 2).map(tactic => 
                        `<span class="mitre-tag">${tactic}</span>`
                    ).join('') : 
                    '<span class="text-secondary">N/A</span>'
                }
                ${alert.mitre_tactics?.length > 2 ? 
                    `<span class="text-secondary" style="font-size: 0.75rem;">+${alert.mitre_tactics.length - 2} more</span>` : 
                    ''
                }
            </td>
            <td>
                <button class="btn btn-outline" onclick="dashboard.showAlertDetails('${alert.id}')" style="padding: 0.5rem; font-size: 0.75rem;">
                    <i class="fas fa-search"></i>
                    Details
                </button>
            </td>
        `;
        
        return row;
    } 

    /**
     * Update pagination
     */
    updatePagination() {
        const totalItems = this.state.filteredAlerts.length;
        this.state.totalPages = Math.ceil(totalItems / this.state.itemsPerPage);
        
        // Update pagination info
        document.getElementById('paginationInfo').textContent = 
            `Showing ${Math.min(this.state.itemsPerPage, totalItems)} of ${totalItems} alerts`;
        
        document.getElementById('tablePaginationInfo').textContent = 
            `Page ${this.state.currentPage} of ${this.state.totalPages}`;
        
        // Update button states
        document.getElementById('firstPage').disabled = this.state.currentPage === 1;
        document.getElementById('prevPage').disabled = this.state.currentPage === 1;
        document.getElementById('nextPage').disabled = this.state.currentPage === this.state.totalPages;
        document.getElementById('lastPage').disabled = this.state.currentPage === this.state.totalPages;
        
        // Update page numbers
        this.updatePageNumbers();
    }

    /**
     * Update page number buttons
     */
    updatePageNumbers() {
        const container = document.getElementById('pageNumbers');
        container.innerHTML = '';
        
        const maxPages = 5;
        let startPage = Math.max(1, this.state.currentPage - Math.floor(maxPages / 2));
        let endPage = Math.min(this.state.totalPages, startPage + maxPages - 1);
        
        if (endPage - startPage + 1 < maxPages) {
            startPage = Math.max(1, endPage - maxPages + 1);
        }
        
        for (let i = startPage; i <= endPage; i++) {
            const button = document.createElement('button');
            button.className = `pagination-btn ${i === this.state.currentPage ? 'active' : ''}`;
            button.textContent = i;
            button.addEventListener('click', () => this.goToPage(i));
            container.appendChild(button);
        }
    }

    /**
     * Go to specific page
     */
    goToPage(page) {
        if (page >= 1 && page <= this.state.totalPages) {
            this.state.currentPage = page;
            this.updateAlertsTable();
            this.updatePagination();
        }
    }

    /**
     * Show alert details modal
     */
    async showAlertDetails(alertId) {
        try {
            const alert = this.state.alerts.find(a => a.id === alertId);
            if (!alert) {
                throw new Error('Alert not found');
            }
            
            const modal = document.getElementById('alertModal');
            const content = document.getElementById('modalContent');
            
            content.innerHTML = this.createAlertDetailContent(alert);
            modal.classList.remove('hidden');
            
        } catch (error) {
            this.showError('Failed to load alert details: ' + error.message);
        }
    }


   

    /**
     * Create alert detail content
     */
    createAlertDetailContent(alert) {
        const severityClass = this.getSeverityClass(alert.severity);
        const timestamp = new Date(alert.timestamp).toLocaleString();
        
        return `
            <div class="alert-detail-grid">
                <div class="detail-card">
                    <h4 class="detail-card-title">Basic Information</h4>
                    <div class="detail-item">
                        <div class="detail-label">Alert ID</div>
                        <div class="detail-value font-mono">${alert.id}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Timestamp</div>
                        <div class="detail-value">${timestamp}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Severity</div>
                        <div class="detail-value">
                            <span class="severity-badge ${severityClass}">
                                Level ${alert.severity}
                            </span>
                        </div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Fired Times</div>
                        <div class="detail-value">${alert.fired_times}</div>
                    </div>
                </div>
                
                <div class="detail-card">
                    <h4 class="detail-card-title">Agent Information</h4>
                    <div class="detail-item">
                        <div class="detail-label">Agent Name</div>
                        <div class="detail-value">${alert.agent_name}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Agent IP</div>
                        <div class="detail-value">${alert.agent_ip}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Agent ID</div>
                        <div class="detail-value">${alert.agent_id}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Manager</div>
                        <div class="detail-value">${alert.manager}</div>
                    </div>
                </div>
                
                <div class="detail-card">
                    <h4 class="detail-card-title">Rule Information</h4>
                    <div class="detail-item">
                        <div class="detail-label">Rule ID</div>
                        <div class="detail-value font-mono">${alert.rule_id}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Description</div>
                        <div class="detail-value">${alert.rule_description}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Groups</div>
                        <div class="detail-value">${alert.groups.join(', ') || 'N/A'}</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Location</div>
                        <div class="detail-value">${alert.location}</div>
                    </div>
                </div>
                
                ${alert.mitre_tactics?.length ? `
                <div class="detail-card">
                    <h4 class="detail-card-title">MITRE ATT&CK</h4>
                    <div class="detail-item">
                        <div class="detail-label">Tactics</div>
                        <div class="detail-value">
                            ${alert.mitre_tactics.map(tactic => 
                                `<span class="mitre-tag">${tactic}</span>`
                            ).join('')}
                        </div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Techniques</div>
                        <div class="detail-value">
                            ${alert.mitre_techniques?.map(tech => 
                                `<span class="mitre-tag" style="background: #7c3aed;">${tech}</span>`
                            ).join('') || 'N/A'}
                        </div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Technique IDs</div>
                        <div class="detail-value">
                            ${alert.mitre_ids?.map(id => 
                                `<span class="mitre-tag" style="background: #6d28d9;">${id}</span>`
                            ).join('') || 'N/A'}
                        </div>
                    </div>
                </div>
                ` : ''}
            </div>
            
            ${alert.full_log ? `
            <div class="detail-card" style="grid-column: 1 / -1;">
                <h4 class="detail-card-title">Full Log</h4>
                <pre style="background: rgba(0, 0, 0, 0.3); padding: 1rem; border-radius: var(--radius-md); overflow-x: auto; font-size: 0.875rem; line-height: 1.4;">${alert.full_log}</pre>
            </div>
            ` : ''}
            
            <div class="detail-card" style="grid-column: 1 / -1;">
                <h4 class="detail-card-title">Raw Data</h4>
                <pre style="background: rgba(0, 0, 0, 0.3); padding: 1rem; border-radius: var(--radius-md); overflow-x: auto; font-size: 0.75rem; line-height: 1.4; max-height: 300px;">${JSON.stringify(alert.raw_data, null, 2)}</pre>
            </div>
        `;
    }

    /**
     * Close modal
     */
    closeModal() {
        document.getElementById('alertModal').classList.add('hidden');
    }

    /**
     * Update summary cards
     */
    updateSummaryCards(summary) {
        document.getElementById('totalAlerts').textContent = 
            summary?.total_alerts?.toLocaleString() || '0';
        document.getElementById('criticalAlerts').textContent = 
            summary?.critical_alerts?.toLocaleString() || '0';
        document.getElementById('highSeverity').textContent = 
            summary?.high_severity_alerts?.toLocaleString() || '0';
        document.getElementById('activeAgents').textContent = 
            summary?.unique_agents?.toLocaleString() || '0';
        document.getElementById('mitreCount').textContent = 
            summary?.mitre_techniques_count?.toLocaleString() || '0';
        
        // Initialize click events after updating the cards
        this.initializeSummaryCardEvents();
    }

    /**
     * Update charts
     */
    updateCharts(chartsData) {
        if (window.chartManager) {
            window.chartManager.updateAllCharts(chartsData);
        }
    }
                

    /**
     * Start real-time updates
     */
    startRealTimeUpdates() {
        setInterval(() => {
            this.loadDashboardData();
        }, this.config.refreshInterval);
    }

    /**
     * Update last refresh time
     */
    updateLastRefreshTime() {
        const element = document.getElementById('lastUpdate');
        if (element) {
            const now = new Date();
            element.innerHTML = `
                <i class="fas fa-clock"></i>
                <span>Last updated: ${now.toLocaleTimeString()}</span>
            `;
        }
    }

    /**
     * Export alerts
     */
    exportAlerts() {
        const data = this.state.filteredAlerts.length > 0 ? this.state.filteredAlerts : this.state.alerts;
        const csv = this.convertToCSV(data);
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `soc-alerts-${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        window.URL.revokeObjectURL(url);
    }

    /**
     * Convert data to CSV
     */
    convertToCSV(data) {
        const headers = ['Timestamp', 'Severity', 'Agent', 'Rule ID', 'Description', 'MITRE Tactics'];
        const rows = data.map(alert => [
            alert.timestamp,
            alert.severity,
            alert.agent_name,
            alert.rule_id,
            `"${alert.rule_description.replace(/"/g, '""')}"`,
            alert.mitre_tactics?.join('; ') || ''
        ]);
        
        return [headers, ...rows].map(row => row.join(',')).join('\n');
    }

    /**
     * Show settings
     */
    showSettings() {
        // Implement settings modal
        alert('Settings feature coming soon!');
    }

    /**
     * Show loading state
     */
    showLoading(show) {
        const overlay = document.getElementById('loadingOverlay');
        if (show) {
            overlay.classList.remove('hidden');
        } else {
            overlay.classList.add('hidden');
        }
    }

    /**
     * Show error message
     */
    showError(message) {
        // Create error notification
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-notification';
        errorDiv.innerHTML = `
            <div style="background: var(--danger-color); color: white; padding: 1rem; border-radius: var(--radius-md); margin-bottom: 1rem; display: flex; justify-content: between; align-items: center;">
                <div>
                    <i class="fas fa-exclamation-circle"></i>
                    ${message}
                </div>
                <button onclick="this.parentElement.remove()" style="background: none; border: none; color: white; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        const container = document.querySelector('.container');
        container.insertBefore(errorDiv, container.firstChild);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (errorDiv.parentElement) {
                errorDiv.remove();
            }
        }, 5000);
    }

    /**
     * Show message to user
     */
    showMessage(message, type = 'info') {
        // Create message element
        const messageEl = document.createElement('div');
        messageEl.className = `filter-message filter-message-${type}`;
        messageEl.innerHTML = `
            <span>${message}</span>
            <button onclick="this.parentElement.remove()">×</button>
        `;
        
        // Add styles
        messageEl.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background: ${type === 'error' ? '#ef4444' : type === 'success' ? '#10b981' : '#3b82f6'};
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            z-index: 10001;
            display: flex;
            align-items: center;
            gap: 1rem;
            max-width: 400px;
        `;
        
        messageEl.querySelector('button').style.cssText = `
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            padding: 0;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
        `;
        
        document.body.appendChild(messageEl);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (messageEl.parentElement) {
                messageEl.remove();
            }
        }, 5000);
    }

    /**
     * Get severity class - UPDATED for range-based severity (1-3: Low, 4-7: Medium, 8-11: High, 12-15: Critical)
     */
    getSeverityClass(severity) {
        if (severity >= 12 && severity <= 15) return 'severity-critical';
        if (severity >= 8 && severity <= 11) return 'severity-high';
        if (severity >= 4 && severity <= 7) return 'severity-medium';
        if (severity >= 1 && severity <= 3) return 'severity-low';
        return 'severity-low'; // fallback for values outside 1-15
    }

    /**
     * Get severity level name - UPDATED for range-based severity (1-3: Low, 4-7: Medium, 8-11: High, 12-15: Critical)
     */
    getSeverityLevel(severity) {
        if (severity >= 12 && severity <= 15) return 'critical';
        if (severity >= 8 && severity <= 11) return 'high';
        if (severity >= 4 && severity <= 7) return 'medium';
        if (severity >= 1 && severity <= 3) return 'low';
        return 'low'; // fallback for values outside 1-15
    }
}

// Utility function for debouncing
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.dashboard = new ProfessionalSOCDashboard();
});
